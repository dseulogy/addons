------------------------------------------------------------
-- BetterEquipSwap -----------------------------------------
-- WRITTEN BY Amurilon -------------------------------------
------------------------------------------------------------
-- RELEASED UNDER CREATIVE COMMONS BY-NC-ND 3.0 ------------
-- http://www.creativecommons.org/licenses/by-nc-nd/3.0/ ---
------------------------------------------------------------




local VERSION = string.match("1.2", "^v?[%d+.]+....$") or DEV_BUILD or "Build: 2015-09-29T17:13:37Z"
local ROOT = "Interface/Addons/BetterEquipSwap"


BetterEquipSwap = {
	System = {
		Name = "BetterEquipSwap",
		Path = ROOT,
		Icon = "interface/bagframe/magicbox-normal.tga",
		Version = VERSION,
		Author = "Amurilon",
	},
	Core = {},
	Frame = {},
}

------------------------------------------------------------
-- NAMESPACE DEFINITIONS -----------------------------------
------------------------------------------------------------
local Plugin = BetterEquipSwap
local Core = Plugin.Core
local Frame = Plugin.Frame

------------------------------------------------------------
-- PERFORMANCE LOCALS --------------------------------------
------------------------------------------------------------
local string = string
local math = math
local table = table
local pairs = pairs
local ipairs = ipairs
local type = type
local tostring = tostring
local tonumber = tonumber
local error = error
local assert = assert
local loadstring = loadstring

------------------------------------------------------------
-- FUNCTIONS -----------------------------------------------
------------------------------------------------------------
function Core.Init()
	EquipSwapButton:Hide()
	QuickSwapEquipBar_slot1:ClearAllAnchors()
	QuickSwapEquipBar_slot1:SetAnchor("BOTTOMRIGHT","TOPLEFT","EquipSwapButton",-32,0)
	QuickSwapEquipBar_slot4:ClearAllAnchors()
	QuickSwapEquipBar_slot4:SetAnchor("TOPLEFT","BOTTOMLEFT",QuickSwapEquipBar_slot1)
end

function Core.Create()
	for i=6,1,-1 do

		local t = {
			_type = "Button",
			_name = "BetterEquipSwap"..i,
			_parent = "EquipmentFrame",
			ID = i,
			MouseEnabled = true,
			NormalTexture = {
				File = "interface/CharacterFrame/EquipSwapButton-Normal",
			},
			HighlightTexture = {
				File = "Interface/Buttons/PanelSmallButtonHighlight",
				AlphaMode = "ADD",
			},
			PushedTexture = {
				File = "interface/CharacterFrame/EquipSwapButton-Depress",
			},
			DisabledTexture = {
				File = "interface/CharacterFrame/EquipSwapButton-Disable",
			},
			Anchors = {
				{ AnchorPoint = "CENTER", RelativePoint = "CENTER", OffsetX = 0, OffsetY = 0},
			},
			Size = {
				Height = 24,
				Width = 24,
			},
			Layers = {
				{
					_type = "FontString",
					_name = "",
					_key = "Text",
					_layer = 3,
					JustifyH = "CENTER",
					Text = i,
					Font = {
						Size = 10,
					},
					Anchors = {
						{ AnchorPoint = "TOPLEFT", RelativePoint = "TOPLEFT", OffsetX = 0, OffsetY = 0 },
						{ AnchorPoint = "BOTTOMRIGHT", RelativePoint = "BOTTOMRIGHT", OffsetX = 0, OffsetY = 0},
					},
				},
			},
			Scripts = {
				OnClick = [[
					BetterEquipSwap.Core.OnClick(this)
					]],
			},
		}
	Frame[i] = ZZLibrary.Widget.Create(t)
	end

	Frame[6]:ClearAllAnchors()
	if CharactFrame_GetEquipSlotCount() > 3 then
		Frame[6]:SetAnchor("BOTTOMRIGHT","TOPLEFT","EquipmentFrame",230,306)
	else
		Frame[6]:SetAnchor("TOPRIGHT","TOPLEFT","EquipmentFrame",230,306)
	end
	Frame[3]:ClearAllAnchors()
	Frame[3]:SetAnchor("BOTTOM","TOP",Frame[6])
	for i=1,2 do
		Frame[i]:ClearAllAnchors()
		Frame[i]:SetAnchor("RIGHT","LEFT",Frame[i+1])
		Frame[i+3]:ClearAllAnchors()
		Frame[i+3]:SetAnchor("RIGHT","LEFT",Frame[i+3+1])
	end

	Frame[GetEuipmentNumber()].Text:SetColor(0,1,0)
	EquipSwapButton:SetFrameStrata("BACKGROUND")

	for i=6,CharactFrame_GetEquipSlotCount()+1,-1 do
		Frame[i]:Hide()
	end

	BetterEquipSwapSave = BetterEquipSwapSave or {}
	if not(BetterEquipSwapSave.Size) then BetterEquipSwapSave.Size = 24 end
	SaveVariables("BetterEquipSwapSave")

	Core.Size(BetterEquipSwapSave.Size)
end

function Core.Size(size)
	local size = size
	if size < 0 or size > 256 then
		print("Size out of range")
		return
	end

	for i=1,6 do
		Frame[i]:SetSize(size,size)
		Frame[i].Text:SetScale(size/24)
	end

	BetterEquipSwapSave.Size = size
end

function Core.OnClick(this)
	for i=1,6 do
		Frame[i].Text:SetColor(1,1,1)
	end
	this.Text:SetColor(0,1,0)
	SwapEquipmentItem(this:GetID()-1)
end

ZZLibrary.Event.Register("LOADING_END", Core.Create, "BetterEquipSwap_Init")
