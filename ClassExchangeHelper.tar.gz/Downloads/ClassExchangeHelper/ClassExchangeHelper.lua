-- Title: ClassExchangeHelper
-- Version: 1.6
-- Author: Pyrrhus
CEH = {
	func={},
	ver="1.7",
	name="ClassExchangeHelper",
	loaded=false,
	classes={},
	vars={
		oldcount=0,
		mc=nil,
		sc=nil,
		Hook,
	},
}

function CEH.func.RegisterEvent(this)
	this:RegisterEvent("LOADING_END")
	
	CEH.func.SetText()
end

function CEH.func.OnEvent(event)
	if event == "EXCHANGECLASS_SHOW" then
		CEH.func.AltKey()
	elseif ( event == "EXCHANGECLASS_CLOSED" ) then
		HideUIPanel(CEHFrame);
	elseif ( event == "EXCHANGECLASS_SUCCESS" ) then
		HideUIPanel(CEHFrame);
	elseif ( event == "EXCHANGECLASS_FAILED" ) then
	elseif(event == "LOADING_END") then
		if not CEH.loaded then
			CEH.func.classes()
			CEH.func.SetText()
			CEH.func.Hook()
			CEH.loaded = true
		end
	end
end

function CEH.func.SetText()
	CEHFrame_name:SetText(TEXT("HOUSE_MAID_HOUSE_CHANGEJOB") )
	CEHFrame_ver:SetText("|H|h|cffbbbbFF|hCEH |H|h|cffbbFFbb|hv"..CEH.ver)
end

local classtable = {}
function CEH.func.classes()
	for id=0,GetClassCount() do
		name,tag=GetClassInfoByID(id)
		classtable[tag]=id+1
	end
end

function CEH.func.Dec(value)
	while true do
		value, k = string.gsub(value, "^(-?%d+)(%d%d%d)", '%1.%2');
		if (k==0) then
			break;
		end
	end
	return value;
end

function CEH.func.GetPlayerClasses()
	CEH.classes={}
	local count, maxNums = GetPlayerNumClasses()
	for i=1,count do
		local name, tag, lvl, Exp, maxExp, debt = GetPlayerClassInfo(i, true);
		local data={ 
			name=name,
			tag=tag,
			id=classtable[tag],
			lvl=lvl,
			xp=Exp,
			maxexp=maxExp,
			debt=debt,
		}
		table.insert(CEH.classes, data)
	end
end

function CEH.func.SetFrameValues()
	if #CEH.classes <4 then
		CEHFrame_2to3class:Show()
		CEHFrame_4to6class:Hide()
		CEHFrame_singleclassheader1:Show()
		CEHFrame_singleclassheader2:Hide()
	else
		if #CEH.classes ==5 then
			CEHFrame_singleclassheader1:Show()
			CEHFrame_singleclassheader2:Hide()
		else
			CEHFrame_singleclassheader1:Hide()
			CEHFrame_singleclassheader2:Show()		
		end
		CEHFrame_2to3class:Hide()
		CEHFrame_4to6class:Show()	
	end
end


function CEH.func.SetStaticFrame()
	local path="/interface/widgeticons/classicon_"
	if #CEH.classes==2 then
		local frame="CEHFrame_2to3class_ChangeButton"
		for i=3,6 do
			_G[frame..i]:Hide()
		end		
		_G[frame.."1"]:SetID(12)
		_G[frame.."1"]:SetText(string.format("%d %s / %s %d", CEH.classes[1].lvl, CEH.classes[1].name, CEH.classes[2].name, CEH.classes[2].lvl))
		UIPanelBackdropFrame_SetTexture(_G[frame.."1_Left"] ,  string.format("%s%s_%s.tga",path,CEH.classes[1].tag,CEH.classes[2].tag), 40 , 40 );
		UIPanelBackdropFrame_SetTexture(_G[frame.."1_Right"] , string.format("%s%s_%s.tga",path,CEH.classes[1].tag,CEH.classes[2].tag), 40 , 40 );
		_G[frame.."2"]:SetID(21)
		_G[frame.."2"]:SetText(string.format("%d %s / %s %d", CEH.classes[2].lvl, CEH.classes[2].name, CEH.classes[1].name, CEH.classes[1].lvl))
		UIPanelBackdropFrame_SetTexture(_G[frame.."2_Left"] ,  string.format("%s%s_%s.tga",path,CEH.classes[2].tag,CEH.classes[1].tag), 40 , 40 );
		UIPanelBackdropFrame_SetTexture(_G[frame.."2_Right"] , string.format("%s%s_%s.tga",path,CEH.classes[2].tag,CEH.classes[1].tag), 40 , 40 );
		
		
	elseif #CEH.classes==3 then
		local frame="CEHFrame_2to3class_ChangeButton"
		for i=3,6 do
			_G[frame..i]:Show()
		end
		_G[frame.."1"]:SetID(12)
		_G[frame.."1"]:SetText(string.format("%d %s / %s %d", CEH.classes[1].lvl, CEH.classes[1].name, CEH.classes[2].name, CEH.classes[2].lvl))
		UIPanelBackdropFrame_SetTexture(_G[frame.."1_Left"] ,  string.format("%s%s_%s.tga",path,CEH.classes[1].tag,CEH.classes[2].tag), 40 , 40 );
		UIPanelBackdropFrame_SetTexture(_G[frame.."1_Right"] , string.format("%s%s_%s.tga",path,CEH.classes[1].tag,CEH.classes[2].tag), 40 , 40 );
		_G[frame.."2"]:SetID(13)
		_G[frame.."2"]:SetText(string.format("%d %s / %s %d", CEH.classes[1].lvl, CEH.classes[1].name, CEH.classes[3].name, CEH.classes[3].lvl))
		UIPanelBackdropFrame_SetTexture(_G[frame.."2_Left"] ,  string.format("%s%s_%s.tga",path,CEH.classes[1].tag,CEH.classes[3].tag), 40 , 40 );
		UIPanelBackdropFrame_SetTexture(_G[frame.."2_Right"] , string.format("%s%s_%s.tga",path,CEH.classes[1].tag,CEH.classes[3].tag), 40 , 40 );
		_G[frame.."3"]:SetID(21)
		_G[frame.."3"]:SetText(string.format("%d %s / %s %d", CEH.classes[2].lvl, CEH.classes[2].name, CEH.classes[1].name, CEH.classes[1].lvl))
		UIPanelBackdropFrame_SetTexture(_G[frame.."3_Left"] ,  string.format("%s%s_%s.tga",path,CEH.classes[2].tag,CEH.classes[1].tag), 40 , 40 );
		UIPanelBackdropFrame_SetTexture(_G[frame.."3_Right"] , string.format("%s%s_%s.tga",path,CEH.classes[2].tag,CEH.classes[1].tag), 40 , 40 );
		_G[frame.."4"]:SetID(23)
		_G[frame.."4"]:SetText(string.format("%d %s / %s %d", CEH.classes[2].lvl, CEH.classes[2].name, CEH.classes[3].name, CEH.classes[3].lvl))
		UIPanelBackdropFrame_SetTexture(_G[frame.."4_Left"] ,  string.format("%s%s_%s.tga",path,CEH.classes[2].tag,CEH.classes[3].tag), 40 , 40 );
		UIPanelBackdropFrame_SetTexture(_G[frame.."4_Right"] , string.format("%s%s_%s.tga",path,CEH.classes[2].tag,CEH.classes[3].tag), 40 , 40 );
		_G[frame.."5"]:SetID(31)
		_G[frame.."5"]:SetText(string.format("%d %s / %s %d", CEH.classes[3].lvl, CEH.classes[3].name, CEH.classes[1].name, CEH.classes[1].lvl))
		UIPanelBackdropFrame_SetTexture(_G[frame.."5_Left"] ,  string.format("%s%s_%s.tga",path,CEH.classes[3].tag,CEH.classes[1].tag), 40 , 40 );
		UIPanelBackdropFrame_SetTexture(_G[frame.."5_Right"] , string.format("%s%s_%s.tga",path,CEH.classes[3].tag,CEH.classes[1].tag), 40 , 40 );
		_G[frame.."6"]:SetID(32)
		_G[frame.."6"]:SetText(string.format("%d %s / %s %d", CEH.classes[3].lvl, CEH.classes[3].name, CEH.classes[2].name, CEH.classes[2].lvl))
		UIPanelBackdropFrame_SetTexture(_G[frame.."6_Left"] ,  string.format("%s%s_%s.tga",path,CEH.classes[3].tag,CEH.classes[2].tag), 40 , 40 );
		UIPanelBackdropFrame_SetTexture(_G[frame.."6_Right"] , string.format("%s%s_%s.tga",path,CEH.classes[3].tag,CEH.classes[2].tag), 40 , 40 );
	else
		local frame="CEHFrame_4to6class_ChangeButton"
		for i=1,6 do
			if i<=#CEH.classes then
				_G[frame..i]:Show()
				_G[frame..i]:SetText(string.format("%s: %d", CEH.classes[i].name, CEH.classes[i].lvl))
			else
				_G[frame..i]:Hide()
			end
		end
	end
	for i=1,6 do
		if i<=#CEH.classes then
			if _G["CEHFrame_singleclassheader1"..i] then
				UIPanelBackdropFrame_SetTexture(_G["CEHFrame_singleclassheader1"..i],string.format("%s%s.tga",path,CEH.classes[i].tag), 40 , 40 );
			end
			UIPanelBackdropFrame_SetTexture(_G["CEHFrame_singleclassheader2"..i],string.format("%s%s.tga",path,CEH.classes[i].tag), 40 , 40 );
		else
			if _G["CEHFrame_singleclassheader1"..i] then
				UIPanelBackdropFrame_SetTexture(_G["CEHFrame_singleclassheader1"..i],"/interface/widgeticons/goodevil_evil02.tga", 40 , 40 );
				_G["CEHFrame_singleclassheader1"..i]:Disable()
			end
			UIPanelBackdropFrame_SetTexture(_G["CEHFrame_singleclassheader2"..i],"/interface/widgeticons/goodevil_evil02.tga", 40 , 40 );
				_G["CEHFrame_singleclassheader2"..i]:Disable()
		end
	end
end

function CEH.func.SetDynFrame()
	local path="/interface/widgeticons/classicon_"
	if #CEH.classes<4 then 
		local class1,class2 = UnitClass("player");
		local level1,level2 = UnitLevel("player")
		for i=1,6 do
			if string.find( _G["CEHFrame_2to3class_ChangeButton"..i]:GetText(),level1.." "..class1.." / "..class2.." "..level2 ) then
				_G["CEHFrame_2to3class_ChangeButton"..i]:Disable()
			else
				_G["CEHFrame_2to3class_ChangeButton"..i]:Enable()
			end			
		end
	else
		local frame="CEHFrame_4to6class_ChangeButton"
		if CEH.vars.mc==nil and CEH.vars.sc==nil then		
			for i=1,#CEH.classes do
				UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Left"] ,  string.format("%s%s.tga",path,CEH.classes[i].tag), 40 , 40 );
				UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Right"] , string.format("%s%s.tga",path,CEH.classes[i].tag), 40 , 40 );	
			end
		elseif CEH.vars.sc==nil then
			for i=1,#CEH.classes do
				if i==CEH.vars.mc then
					UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Left"] , string.format("%s%s.tga", path,	CEH.classes[CEH.vars.mc].tag), 40 , 40 );
					UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Right"] , string.format("%s%s.tga",path,	CEH.classes[CEH.vars.mc].tag), 40 , 40 );
				else
					UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Left"] , string.format("%s%s_%s.tga", path,	CEH.classes[CEH.vars.mc].tag,CEH.classes[i].tag), 40 , 40 );
					UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Right"] , string.format("%s%s_%s.tga",path,	CEH.classes[CEH.vars.mc].tag,CEH.classes[i].tag), 40 , 40 );
				end
			end
		elseif CEH.vars.mc==nil then
			for i=1,#CEH.classes do
				if i==CEH.vars.sc then
					UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Left"] , string.format("%s%s.tga", path,CEH.classes[i].tag), 40 , 40 );
					UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Right"] , string.format("%s%s.tga",path,CEH.classes[i].tag), 40 , 40 );
				else	
					UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Left"] , string.format("%s%s_%s.tga", path,CEH.classes[i].tag,	CEH.classes[CEH.vars.sc].tag), 40 , 40 );
					UIPanelBackdropFrame_SetTexture(_G[frame..i.."_Right"] , string.format("%s%s_%s.tga",path,CEH.classes[i].tag,	CEH.classes[CEH.vars.sc].tag), 40 , 40 );	
				end
			end
		end
	end
end

function CEH.func.OnFrameShow()
	if CEH.vars.oldcount~=GetPlayerNumClasses() then
		CEH.func.GetPlayerClasses()
		CEH.func.SetFrameValues()
		CEH.func.SetStaticFrame()	--Gleichbleibende Inhalte
		CEH.vars.oldcount=GetPlayerNumClasses()
	end
	CEH.vars.sc=nil
	CEH.vars.mc=nil
	CEH.func.SetDynFrame()
end

local eventtbl={
	"EXCHANGECLASS_SHOW",
	"EXCHANGECLASS_CLOSED",
	"EXCHANGECLASS_SUCCESS",
	"EXCHANGECLASS_FAILED",
}
-- create hooks
function CEH.func.Hook()

    CEH.ToggleUIFrame = ToggleUIFrame;
	
    function ToggleUIFrame(frame)
        if(frame == ExchangeClassFrame) then frame = CEHFrame; end;
        CEH.ToggleUIFrame(frame);
    end;   

    local success,errmsg = pcall(CEH.func.InitGameFrames);
    if not success then 
		SendWarningMsg("|cffbbbbbbCEH- FrameInit: "..errmsg);
    end;    
	CEH.vars.Hook=true;
end;

function CEH.func.InitGameFrames()
	for i=1,#eventtbl do
		CEHFunc:RegisterEvent(eventtbl[i])
		ExchangeClassFrame:UnregisterEvent(eventtbl[i])
	end    
end;

function CEH.func.UnHook()
	ToggleUIFrame= CEH.ToggleUIFrame;
	for i=1,#eventtbl do
		ExchangeClassFrame:RegisterEvent(eventtbl[i])
		CEHFunc:UnregisterEvent(eventtbl[i])
	end 
	CEH.vars.Hook=false;
end;

function CEH.func.ExchangeClassByClassIndex(c1,c2)
	if c1 and c2 and c1<=#CEH.classes and c2<=#CEH.classes	then
		local class1,class2=UnitClass("player")
		if c2==0 then
			if CEH.classes[c1].name ~=class1   then
				ExchangeClass(CEH.classes[c1].id,0)
			else
				HideUIPanel(CEHFrame);
			end
		elseif c1==c2 then
			if CEH.classes[c1].name==class1 and class2=="" then
				HideUIPanel(CEHFrame);
			else
				ExchangeClass(CEH.classes[c1].id,0)
			end
		else
			if CEH.classes[c1].name~=class1 or CEH.classes[c2].name~=class2 then 
				ExchangeClass(CEH.classes[c1].id, CEH.classes[c2].id)
			else
				HideUIPanel(CEHFrame);
			end
		end
	else
		SendWarningMsg(tostring(c1).." "..tostring(c2).." <--error, index")
	end
end

function CEH.func.SetTooltip(frame,c1)
	GameTooltip:SetOwner(frame, "ANCHOR_LEFT", 4, 0) -- Set Owner --
	GameTooltip:ClearLines() -- Clear tooltip --
	if c1<=#CEH.classes then 
		GameTooltip:AddLine(CEH.classes[c1].name .." " .. CEH.classes[c1].lvl, 0.75, 0.75, 0.75)
		GameTooltip:AddSeparator()
		GameTooltip:AddLine("XP:"..CEH.func.Dec(CEH.classes[c1].xp).."\/"..CEH.func.Dec(CEH.classes[c1].maxexp)..": "..math.floor(CEH.classes[c1].xp/CEH.classes[c1].maxexp*10000+0.5)/100 .."%")
	else
		GameTooltip:AddLine(CEH.name, 0.75, 0.75, 0.75)			
	end
	GameTooltip:Show()
end

function CEH.func.AltKey()
	if IsAltKeyDown() then
	local mc, sc = UnitClass("player");
		if sc~="" then
			local mid,sid
			for i=1,#CEH.classes do
				if CEH.classes[i].name==mc then
					mid=i
				elseif CEH.classes[i].name==sc then
					sid=i
				end
			end
			CEH.func.ExchangeClassByClassIndex(sid,mid)
			CloseExchangeClass();
		else		
			CEHFrame:Show()
		end
	else
		CEHFrame:Show()
	end
end
--[[ slash commands ]]

    SLASH_CEH1 = "/CEH";

SlashCmdList["CEH"] = function(editBox, msg)
	if not CEH.vars.Hook then 
		CEH.func.Hook()
		DEFAULT_CHAT_FRAME:AddMessage("|H|h|cff00ff00|hCEH active");
	else
		CEH.func.UnHook()
		DEFAULT_CHAT_FRAME:AddMessage("|H|h|cffff0000|hCEH inactive");
	end
end;

local orig_ExchangeClass=ExchangeClass
function ExchangeClass(class1,class2)
	if class1==nil then
	
	else
		orig_ExchangeClass(class1,class2)
	end
end