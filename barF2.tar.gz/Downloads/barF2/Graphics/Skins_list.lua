-----------------------------------------------------------
---                   barF2 Skins List                ---
---    Add skins to this directory   ..  "skin name",   ---
---         and skin folder in this folder too          ---
---        REMEMBER case sensative file names           ---
-----------------------------------------------------------

return {
		
			"boring",   --using game textures will not find folder for it--
			"Circle",
			"Square",
			"Slayblaze",
			"Slayblaze_buff_green",
			"WoW",
			"Hexed",
			"Syndi",
			"Syndi_invalid_norm",			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			

};