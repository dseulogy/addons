local ToonName,ToonClass;
local barF2_Binding_Old,barF2_Binding_Name,barF2_Binding_New,barF2_Binding_fKey,barF2_Binding_Key;

local selected_bar,selected_button =0,0;
function barF2_GetSelected()
	return selected_bar,selected_button;
end
--- Open / Close Config
function barF2_MINIMAP_Click()
	if barF2.GLOBAL.Mode == "Normal" then
		getglobal("barF2_Config_Main_Frame"):Show();
		barF2.GLOBAL.Mode = "Config";
		barF2_place();
		barF2_ShowNumbers();
	elseif barF2.GLOBAL.Mode == "Config" then
		getglobal("barF2_Config_Main_Frame"):Hide();
		barF2_Reset_Selected();
		barF2.GLOBAL.Mode = "Normal";
		barF2_ShowNumbers();
	end
end


-- refresh all config elements --
function barF2_ReFresh_Config() 
	local extra = barF2_Config_Extras_Frame:IsVisible();
	local bar   = barF2_Config_Bar_Frame   :IsVisible();
	local button= barF2_Config_Button_Frame:IsVisible();
	getglobal("barF2_Config_Main_Frame"):Hide();
	getglobal("barF2_Config_Main_Frame"):Show();
	if (bar == true) or (selected_bar>0) then barF2_Config_Bar_Frame:Show() end;
	if (button == true) or (selected_button>0) then barF2_Config_Button_Frame:Show() end;
	if extra == true then barF2_Config_Extras_Frame:Show() end;
	barF2.GLOBAL.Mode = "Config";
end


function barF2Set(frame,point,rpoint,parent,x,y)
	frame:Show();
	frame:ClearAllAnchors();
	frame:SetAnchor(point,rpoint,parent,x,y);
end

local last_bar = 0;

function barF2_Config_Main_Init()
	ToonName,ToonClass = barF2_Toon();
	getglobal("barF2_Config_Main_FrameVersion"):SetText(barF2.GLOBAL.Version);
	getglobal("barF2_Config_Main_FrameVersion"):SetColor(0,0.8,1);
	getglobal("barF2_Config_Main_Frame"):SetBackdropTileColor(0,1,1);
	-- Layout
	barF2Set(getglobal("barF2_LayoutSlider"),"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",355,40);
	getglobal("barF2_LayoutSlider"):SetValue(barF2.GLOBAL.Use);
	getglobal("barF2_LayoutSliderText"):SetText(barF2.GLOBAL.Use);
	-- Hide Blanks passive
	barF2Set(getglobal("barF2_HideBlank_Box"),"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",140,5);
	getglobal("barF2_HideBlank_Box"):SetChecked(barF2.GLOBAL.Blank);
	getglobal("barF2_HideBlank_BoxLeftText"):SetText("Hide Blanks:");
	-- Show Binding text
	barF2Set(getglobal("barF2_ShowBinding_Box"),"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",140,35);
	getglobal("barF2_ShowBinding_Box"):SetChecked(barF2.GLOBAL.Hot);
	getglobal("barF2_ShowBinding_BoxLeftText"):SetText("Show Binding:");
	-- Lock drag/drop
	barF2Set(getglobal("barF2_LockSkills_Box"),"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",140,65);
	getglobal("barF2_LockSkills_Box"):SetChecked(barF2.GLOBAL.Lock);
	getglobal("barF2_LockSkills_BoxLeftText"):SetText("Lock :");
	--Main skin gloss
	barF2Set(getglobal("barF2_MainGloss_Box"),"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",285,65);
	if barF2.GLOBAL.Skin == "boring" then 
		barF2.GLOBAL.Glossy = false
		barF2_CHAR[ToonName][ToonClass].Glossy = barF2.GLOBAL.Glossy
	end
	getglobal("barF2_MainGloss_Box"):SetChecked(barF2.GLOBAL.Glossy);
	getglobal("barF2_MainGloss_BoxLeftText"):SetText("Gloss :");	
	--Main Skin dropdown
	barF2Set(getglobal("barF2_MainSkin_Menu"),"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",235,40);
	getglobal("barF2_MainSkin_MenuTopText"):SetText("Main Skin");
	UIDropDownMenu_SetText(getglobal("barF2_MainSkin_Menu_DropDown"),barF2.GLOBAL.Skin);
	UIDropDownMenu_Initialize(getglobal("barF2_MainSkin_Menu_DropDown"),barF2_MainSkin_Menu_init);
	--Extras menu button
	barF2Set(getglobal("barF2_Extras_Button"),"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",4,80);
	getglobal("barF2_Extras_Button"):SetText("Extras");
	getglobal("barF2_Extras_Button"):SetSize(60,20);
	local shif = 0
	if barF2.GLOBAL.Shift == false then shif = 200 end
	last_bar = 0;
	for i = 1,10 do
		local frame =getglobal("barF2BKG_"..i)
		frame:SetSize(230+shif,60);
		frame:SetBackdropTileColor(0.4,0.4,0);
		frame:Hide();
		getglobal("barF2CR_"..i) :Hide();
		getglobal("barF2RW_"..i) :Hide();
		getglobal("barF2SHB_"..i):Hide();
		if getglobal("barF2_Config_Main_Frame_MINIMIZE"):IsVisible()then 
			if (barF2["layout"..barF2.GLOBAL.Use].Bars[i].count > 0 ) or (barF2.GLOBAL.Shift == false) then
				last_bar = last_bar + 1
				frame = getglobal("barF2BKG_"..i);
				local barshif = 0
				if selected_bar == i then barshif = 30 end
				barF2Set(frame,"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",barshif,last_bar * 60 +50);
				if barF2.GLOBAL.Shift == false then
	--bar count
					barF2Set(getglobal("barF2CR_"..i),"TOPLEFT","TOPLEFT",frame:GetName(),10,22);
					getglobal("barF2CR_"..i)             :SetValue(barF2["layout"..barF2.GLOBAL.Use].Bars[i].count);
					getglobal("barF2CR_"..i.."Text")    :SetText(barF2["layout"..barF2.GLOBAL.Use].Bars[i].count);
	--bar row
					barF2Set(getglobal("barF2RW_"..i),"TOPLEFT","TOPLEFT",frame:GetName(),120,22);
					getglobal("barF2RW_"..i)             :SetValue(barF2["layout"..barF2.GLOBAL.Use].Bars[i].row);
					getglobal("barF2RW_"..i.."Text")     :SetText(barF2["layout"..barF2.GLOBAL.Use].Bars[i].row);
				end
	--bar show
				barF2Set(getglobal("barF2SHB_"..i),"TOPLEFT","TOPLEFT",frame:GetName(),60+shif,15);
				getglobal("barF2SHB_"..i)                 :SetChecked(barF2["layout"..barF2.GLOBAL.Use].Bars[i].show);
				getglobal("barF2SHB_"..i.."LeftText")    :SetText("# "..i);
				getglobal("barF2SHB_"..i.."LeftText")    :SetColor(1,0,1);
			end
		end
	end
	barF2_Update_Tottext();		
			
end
function barF2_Config_Bar_Init()
	local shif = 0
	if barF2.GLOBAL.Shift == false then shif = 200 end
	local frame =  getglobal("barF2_Config_Bar_Frame");
	if getglobal("barF2_Config_Main_Frame_MAXIMIZE"):IsVisible()then
		frame:Hide();
		return;
	end
	barF2Set(frame,"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",250+shif,110);
	frame                                        : SetBackdropEdgeColor(1,0,1);
	frame                                        : SetBackdropTileColor(1,1,0);
	getglobal("barF2_Config_Bar_Frame_Number")   : SetText("#"..selected_bar);
	getglobal("barF2_Config_Bar_Frame_Number")   : SetColor(1,0,1);
	barF2Set(getglobal("barF2_BAR_adjust"),"TOPLEFT","TOPLEFT",frame:GetName(),164,50);
	--bar scale
	barF2Set(getglobal("barF2SC_1"),"TOPLEFT","TOPLEFT",frame:GetName(),20,30);
	getglobal("barF2SC_1")                       :SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].scale);
	getglobal("barF2SC_1Text")                   :SetText(string.format("%.2f",barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].scale));
	--bar spacing
	barF2Set(getglobal("barF2SP_1"),"TOPLEFT","TOPLEFT",frame:GetName(),20,80);
	getglobal("barF2SP_1")                       :SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].Spacing);
	getglobal("barF2SP_1Text")                   :SetText(barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].Spacing);
	--bar skin now
	barF2Set(getglobal("barF2_BarSkin_Menu"),"TOPLEFT","TOPLEFT",frame:GetName(),40,120);
	if barF2.GLOBAL.Shift == true then
		getglobal("barF2_BarSkin_MenuRightText")  :SetText(":Skin Group");
	else
		getglobal("barF2_BarSkin_MenuRightText")  :SetText(":Skin Bar");
	end
	UIDropDownMenu_SetText(getglobal("barF2_BarSkin_Menu_DropDown"),"vv       vv");
	UIDropDownMenu_Initialize(getglobal("barF2_BarSkin_Menu_DropDown"),barF2_BarSkin_Menu_init);
	--bar Show when pressed
	barF2Set(getglobal("barF2_BarIsPressed_Menu"),"TOPLEFT","TOPLEFT",frame:GetName(),40,160);
	getglobal("barF2_BarIsPressed_MenuRightText")  :SetText(":Show When Pressed");
	UIDropDownMenu_SetText(getglobal("barF2_BarIsPressed_Menu_DropDown"),barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].IsPressed);
	UIDropDownMenu_Initialize(getglobal("barF2_BarIsPressed_Menu_DropDown"),barF2_BarIsPressed_Menu_init);
	--bar x,y adjuster
	
end
function barF2_Config_Button_Init()
	local shif = 0
	if barF2.GLOBAL.Shift == false then shif = 200 end
	local frame =  getglobal("barF2_Config_Button_Frame");
	if getglobal("barF2_Config_Main_Frame_MAXIMIZE"):IsVisible()then
		frame:Hide();
		return;
	end
	barF2Set(frame,"TOPLEFT","TOPLEFT","barF2_Config_Main_Frame",250+shif,330);
	frame                                          : SetBackdropEdgeColor(1,0.5,0);
	frame                                           : SetBackdropTileColor(0,1,1);
	getglobal("barF2_Config_Button_Frame_Number")  : SetText(selected_button);
	getglobal("barF2_Config_Button_Frame_Number")  : SetColor(1,0.5,0);
	local btn_parent = barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].parent
	--btn scale
	if btn_parent == "UIParent" then
		barF2Set(getglobal("barF2ButtonScaleSlider"),"TOPLEFT","TOPLEFT",frame:GetName(),20,60);
		getglobal("barF2ButtonScaleSlider")        :SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].scale);
		getglobal("barF2ButtonScaleSliderText")    :SetText(string.format("%.2f",barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].scale));
		barF2Set(getglobal("barF2_BUTTON_adjust"),"TOPLEFT","TOPLEFT",frame:GetName(),164,100);        
	else
		getglobal("barF2ButtonScaleSlider")        :Hide();
		getglobal("barF2_BUTTON_adjust")           :Hide();
	end
	--btn show
	barF2Set(getglobal("barF2_ShowButton_Box"),"TOPLEFT","TOPLEFT",frame:GetName(),90,10);
	getglobal("barF2_ShowButton_Box")              :SetChecked(barF2_CHAR[ToonName][ToonClass][selected_button].show );
	getglobal("barF2_ShowButton_BoxLeftText")      :SetText("Show :");
	--btn autohide
	barF2Set(getglobal("barF2_AutoHide_Box"),"TOPLEFT","TOPLEFT",frame:GetName(),260,10);
	getglobal("barF2_AutoHide_Box")                :SetChecked(barF2_CHAR[ToonName][ToonClass][selected_button].autohide );
	getglobal("barF2_AutoHide_BoxLeftText")        :SetText("Hide Till Ready :");
	getglobal("barF2_AutoHide_BoxLeftText")        :SetColor(0.5,0.5,0.5);
	--btn Gloss
	barF2Set(getglobal("barF2_GlossButton_Box"),"TOPLEFT","TOPLEFT",frame:GetName(),90,230);
	getglobal("barF2_GlossButton_Box")             :SetChecked(barF2_CHAR[ToonName][ToonClass][selected_button].gloss );
	getglobal("barF2_GlossButton_BoxLeftText")     :SetText("Gloss:");
	--btn reset binding
	barF2Set(getglobal("barF2_ClearBinding_Button"),"TOPLEFT","TOPLEFT",frame:GetName(),165,235);
	getglobal("barF2_ClearBinding_Button")         :SetSize(100,20);
	getglobal("barF2_ClearBinding_Button")         :SetText("Clear Binding");
	--btn binding
	barF2_Binding_Name                            = "ACTIONBAR"..math.ceil(selected_button/20) .."BUTTON"..(selected_button-(math.ceil(selected_button/20)*20-20));
	barF2_Binding_Old                             = GetBindingKey(barF2_Binding_Name);
	if (barF2_Binding_Old) then
		barF2BindingButton                        : SetText(barF2_Binding_Old);
		barF2BindingButton                        : SetTextColor(1,0.5,0);
	else
		barF2BindingButton                        : SetText("undefined");
	end
	barF2_Binding_fKey                            = nil
	barF2_Binding_Key                             = nil

	--btn skin dropdown
	barF2Set(getglobal("barF2_ButtonSkin_Menu"),"TOPLEFT","TOPLEFT",frame:GetName(),40,200);
	getglobal("barF2_ButtonSkin_MenuTopText")     :SetText("Skin:");
	UIDropDownMenu_SetText(getglobal("barF2_ButtonSkin_Menu_DropDown"),barF2_CHAR[ToonName][ToonClass][selected_button].skin);
	UIDropDownMenu_Initialize(getglobal("barF2_ButtonSkin_Menu_DropDown"),barF2_ButtonSkin_Menu_init);
	--btn strata
	barF2Set(getglobal("barF2_ButtonStrata_Menu"),"TOPLEFT","TOPLEFT",frame:GetName(),40,130);
	getglobal("barF2_ButtonStrata_MenuTopText")    :SetText("Strata");
	UIDropDownMenu_SetText(getglobal("barF2_ButtonStrata_Menu_DropDown"),barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].strata);
	UIDropDownMenu_Initialize(getglobal("barF2_ButtonStrata_Menu_DropDown"),barF2_ButtonStrata_Menu_init);
	
end
function barF2_Config_Extras_Init()
	local frame = getglobal("barF2_Config_Extras_Frame");
	frame                                           : SetBackdropTileColor(0,1,1);
	-- show all buttons now
	barF2Set(getglobal("barF2_ShowAll_Button"),"TOPLEFT","TOPLEFT",frame:GetName(),40,20);
	getglobal("barF2_ShowAll_Button")              :SetSize(120,40);
	getglobal("barF2_ShowAll_Button")              :SetText("Show All");
	-- Hide all blank now
	barF2Set(getglobal("barF2_HideAllUnused_Button"),"TOPLEFT","TOPLEFT",frame:GetName(),40,70);
	getglobal("barF2_HideAllUnused_Button")        :SetSize(120,40);
	getglobal("barF2_HideAllUnused_Button")        :SetText("Hide Unused");
	-- Sticky tooltip
	barF2Set(getglobal("barF2_ToolTip_Box"),"TOPLEFT","TOPLEFT",frame:GetName(),130,140);
	getglobal("barF2_ToolTip_Box")                 :SetChecked(barF2.GLOBAL.Tooltip.Mode );
	getglobal("barF2_ToolTip_BoxLeftText")         :SetText("Sticky ToolTip:");
	-- set sticky tooltip
	barF2Set(getglobal("barF2_PostionTooltip_Button"),"TOPLEFT","TOPLEFT",frame:GetName(),40,180);
	getglobal("barF2_PostionTooltip_Button")       :SetSize(120,35);
	getglobal("barF2_PostionTooltip_Button")       :SetText("Set ToolTip Position");
	-- Group mode on/off
	barF2Set(getglobal("barF2_GroupMode_Box"),"TOPLEFT","TOPLEFT",frame:GetName(),130,250);
	getglobal("barF2_GroupMode_Box")               :SetChecked(barF2["layout"..barF2.GLOBAL.Use].Shift );
	getglobal("barF2_GroupMode_BoxLeftText")       :SetText("Group Mode:");
	-- Default spacing for group mode
	if barF2.GLOBAL.Shift == true then
		barF2Set(getglobal("barF2DefaultSpacingSlider"),"TOPLEFT","TOPLEFT",frame:GetName(),50,300);
		getglobal("barF2DefaultSpacingSlider")      :SetValue(barF2.GLOBAL.Spacing);
		getglobal("barF2DefaultSpacingSliderText")  :SetText("Default :"..barF2.GLOBAL.Spacing);
	else
		getglobal("barF2DefaultSpacingSlider"):Hide();
	end
end
--if menu bar clicked or value changed within, 
function barF2_Config_EnterBar(this)
	if selected_bar ~= (this:GetID()) - 50 then
		selected_bar = (this:GetID()) - 50
		barF2_Config_Button_Frame:Hide();
		selected_button = 0;
		if barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].count >0 then
			barF2_Config_Bar_Frame:Show();
		else
			barF2_Config_Bar_Frame:Hide();
		end
		barF2_ReFresh_Config();
	end
end
--Total buttons used in bars/groups
function barF2_Count_Tot()
	local bttn_Count=0
	for i=1,10 do
		bttn_Count = bttn_Count + barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count
	end
	return bttn_Count;
end
-- Show text to represent where and how many buttons used in bars/groups
function barF2_Update_Tottext()
	local bttn_Count = barF2_Count_Tot();
	if bttn_Count == 80 then
		getglobal("barF2_Config_Main_Frame_Count_text")                             : SetText("MAX 80 Buttons used in Bars");
	elseif (barF2.GLOBAL.Shift == false) then
		getglobal("barF2_Config_Main_Frame_Count_text")                             : SetText(bttn_Count.." Buttons in bars  "..(80-bttn_Count).." Free");
	elseif (barF2.GLOBAL.Shift == true) then
		getglobal("barF2_Config_Main_Frame_Count_text")                             : SetText(bttn_Count.." Buttons in Groups "..(80-bttn_Count).." Free");
	end
	local brange = 0
	for i=1,10 do
		if barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count == 0 then
			getglobal("barF2SHB_" ..i .."RightText")   : SetText(" ");
		elseif (barF2.GLOBAL.Shift == false) then
			brange  = brange + barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count;
			getglobal("barF2SHB_" ..i .."RightText")   : SetText("Buttons :"..(brange-barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count+1).." to "..brange);
		elseif (barF2.GLOBAL.Shift == true) then
			getglobal("barF2SHB_" ..i .."RightText")   : SetText("Buttons = " ..barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count);
		end
	end

end
--xy incremeter
local xHELD, yHELD,fHELD,xyHELD = 0,0,"",false;
function barF2_xyadjust(x,y,frame)
	xHELD, yHELD,fHELD = x,y,frame;
	if xyHELD == false then
		barF2_xyadjuster_Timer:Show();
		xyHELD = true;
	end
	if string.find(frame,"BAR") then
		barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].x = barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].x + x
		barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].y = barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].y + y
	else
		barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].x = barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].x + x
		barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].y = barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].y + y
	end
	barF2_place();
end
function barF2_xyadjust_Time(this,elapsedTime)
	this.update = this.update - elapsedTime;
	if this.update < 0 then
		this.update = 0;
		barF2_xyadjust(xHELD,yHELD,fHELD);
	end
end
barF2_adjust_TimeEnd=function() 
	xyHELD = false 
	barF2_xyadjuster_Timer:Hide();
end;
	
--reset selected
function barF2_Reset_Selected()
	selected_bar = 0;
	selected_button = 0;
end
--get selected button and if in bar/group also selected bar
function barF2_SelectedButton(this)
	selected_button = this:GetID();
	local obj = barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].parent;
	barF2_Config_Button_Frame:Show();
	if obj ~= "UIParent" then
		if selected_bar ~= getglobal(obj):GetID() then
			selected_bar = getglobal(obj):GetID();
			barF2_Config_Bar_Frame:Show();
		end
	else
		selected_bar = 0
		barF2_Config_Bar_Frame:Hide();
	end
	barF2_ReFresh_Config();
end
--Scale with wheel--
function barF2_ScaleWheel(this,delta)
	local obj = barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].parent;
	
	delta = delta / math.abs(delta);
	
	if (obj == "UIParent") then   --freeroaming button
		barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].scale = barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].scale + (delta *0.01);
		barF2_Bttn_Scale(ind,barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].scale);
		getglobal("barF2ButtonScaleSliderText"):SetText(string.format("%.2f",barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].scale));
		getglobal("barF2ButtonScaleSlider"):SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].scale)
		barF2_place();
	else                           --button in bar/group so scale whole bar
		obj=getglobal(obj);
		selected_bar = obj:GetID();
		barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].scale = barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].scale + (delta * 0.01);
		getglobal("barF2SC_1Text"):SetText(string.format("%.2f",barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].scale));
		getglobal("barF2SC_1"):SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].scale)
		barF2_SortButtons_Bars();
		barF2_place();
	end						
end
---BINDINGS SETTING--
--button is clicked and turn on keyboard to get key pressed
function barF2_Binding_Click()
	barF2BindingButton:LockHighlight();
	barF2BindingButton:SetText ("Define Key Now");
	barF2BindingButton:SetTextColor(1,0.5,0);
	barF2BindingButton:SetKeyboardEnable(true);
end
-- check for ctrl,alt,shift key is held down
function barF2_OnKeyDown(key)
	if (key~=nil) then   
        if (key=="CTRL" or key=="SHIFT" or key=="ALT") then
				barF2_Binding_fKey=key;
		end
	end
end
--if cancelled return button to previous state
function barF2_Binding_Hide()
		barF2BindingButton:SetKeyboardEnable(false);
		barF2_Binding_Key = nil;
		barF2_Binding_fKey=nil;
		barF2BindingButton:UnlockHighlight();
		if (barF2_Binding_Old) then
			barF2BindingButton:SetText(barF2_Binding_Old)
			barF2BindingButton:SetTextColor(1,1,1)
		else
			barF2BindingButton:SetText("Undefined")
			barF2BindingButton:SetTextColor(1,1,0)
		end
		barF2_place();
end
-- clear binding for button
function barF2_Binding_Clear()
	SetBindingKey(barF2_Binding_Name,KDF_UNDEFINE);
	barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].Hotkey = "undefined"
	SaveBindingKey();
	barF2_Binding_Old = GetBindingKey(barF2_Binding_Name)
	if (barF2_Binding_Old) then
		barF2BindingButton:SetText(barF2_Binding_Old)
		barF2BindingButton:SetTextColor(1,0.5,0)
	else
		barF2BindingButton:SetText("Undefined")
		barF2BindingButton:SetTextColor(1,1,0)
	end
	barF2_Hotkeys_Layout();
end
-- when key is released check to see if being canceled first then if not get key to set binding
function barF2_OnKeyUp(key)
	if ( key=="ESCAPE" ) then
		barF2BindingButton:SetKeyboardEnable(false);
		barF2_Binding_Key = nil;
		barF2_Binding_fKey=nil;
		barF2BindingButton:UnlockHighlight();
		if (barF2_Binding_Old) then
			barF2BindingButton:SetText(barF2_Binding_Old)
			barF2BindingButton:SetTextColor(1,0.5,0)
		else
			barF2BindingButton:SetText("Undefined")
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].Hotkey = "undefined"
			barF2BindingButton:SetTextColor(1,1,0)
		end
		return;
	end
	if ( key==nil ) then   
		return;
	end
	if (key=="CTRL" or key=="SHIFT" or key=="ALT") then
		barF2_Binding_fKey=nil;
		return;
	end
	barF2BindingButton:SetKeyboardEnable(false);
	barF2BindingButton:UnlockHighlight();
	barF2_Binding_New = key
	if (barF2_Binding_fKey ~= nil) then
		barF2_Binding_New =barF2_Binding_fKey.."+"..key
	end
	barF2BindingButton:SetText (barF2_Binding_New)
	barF2BindingButton:SetTextColor(0,1,0)
	SetBindingKey(barF2_Binding_Name,barF2_Binding_New)
	SaveBindingKey();
	barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].Hotkey = GetBindingKey(barF2_Binding_Name);
	barF2_Hotkeys_Layout();
end

--MOVEMENT OF BARS?GROUPS AND BUTTONS--

local xybttns={}
for i=1,80 do
	xybttns[i] = {["leftx"] = 0,["lefty"] = 0,["rightx"]=0,["righty"]=0,["array"]=0,}
end
local bttn_enter,bttn_array,bttn_old,bttn_new,group_new = -1,false,-1,-1,-1
local xyarray={}
for i=1,9 do
	xyarray[i]={["leftx"] = 0,["lefty"] = 0,["rightx"]=0,["righty"]=0,}
end
--convert
function barF2_Convert(i,p)
	local bParent= barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].parent;
	if bParent == "UIParent" then
		return (p);
	else
		local bSPACE = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(bParent):GetID()].Spacing;
		local bSc    = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(bParent):GetID()].scale;
		return (((p *(42+bSPACE))-(41+bSPACE)) * bSc);
	end
end
--start moving
function barF2_StartMoving(this,key)
	local obj = barF2["layout" ..barF2.GLOBAL.Use].Bttns[this:GetID()].parent
	if (key == "RBUTTON") then
		if (obj ~= "UIParent") then
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[this:GetID()].x,barF2["layout" ..barF2.GLOBAL.Use].Bttns[this:GetID()].y = this:GetPos();
			barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].count  =  barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].count -1
			if (barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].count < barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].row) then
				barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].row = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].count
			end
		end
		obj = "UIParent"
		barF2["layout" ..barF2.GLOBAL.Use].Bttns[this:GetID()].parent = obj
		if (barF2.GLOBAL.Shift == false) then
			barF2.GLOBAL.Shift = true
			barF2["layout" ..barF2.GLOBAL.Use].Shift = true
		end
		barF2_SelectedButton(this);
		barF2.GLOBAL.Shifter = this:GetID();
		barF2_ReFresh_Config();
		barF2_xydata();
		barF2_xydataShow();
		barF2_Shift_Frame:Show();
	end
	if (obj == "UIParent") then
		this:StartMoving("TOPLEFT");
	else
		selected_bar = getglobal(obj):GetID();
		getglobal(obj):StartMoving("TOPLEFT");
	end
end
--table of all buttons xy position
function barF2_xydata()
	barF2_place();
	for i=1,80 do
		if (i ~= barF2.GLOBAL.Shifter) then
			local obj=barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].parent
			if (obj=="UIParent") then
				xybttns[i].leftx    =     barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x 
				xybttns[i].lefty    =     barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y 
				xybttns[i].rightx   =     xybttns[i].leftx +(32 * barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].scale)
				xybttns[i].righty   =     xybttns[i].lefty +(32 * barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].scale)
			else
				xybttns[i].leftx , xybttns[i].lefty  = getglobal("barF2_"..i):GetPos()
				xybttns[i].rightx   =     xybttns[i].leftx +(32 * barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].scale)
				xybttns[i].righty   =     xybttns[i].lefty +(32 * barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].scale)
			end
		end
	end
end
function barF2_xydataShow()
	local sc = GetUIScale();
	for i=1,80 do
		if (i~=barF2.GLOBAL.Shifter) then
			getglobal("barF2_" ..i):ClearAllAnchors();
			getglobal("barF2_" ..i):SetAnchor("TOPLEFT","TOPLEFT","UIParent",xybttns[i].leftx/sc,xybttns[i].lefty/sc);
		end
	end
end
--moving with right mouse down
function barF2_Shift_Move()
	local x,y = getglobal("barF2_" ..barF2.GLOBAL.Shifter):GetPos();
	barF2_Bttn_Scale(barF2.GLOBAL.Shifter,0.5);
	local xl = x+16 
	local yl = y+16
	barF2["layout" ..barF2.GLOBAL.Use].Bttns[barF2.GLOBAL.Shifter].x = x
	barF2["layout" ..barF2.GLOBAL.Use].Bttns[barF2.GLOBAL.Shifter].y = y
	---locate movement to see if over a button---
	for i =1,80 do
		if (i ~= barF2.GLOBAL.Shifter) then
			if (x > xybttns[i].leftx) and (x < xybttns[i].rightx) and (y > xybttns[i].lefty) and (y < xybttns[i].righty) then
				bttn_new = i	
			elseif (xl > xybttns[i].leftx) and (xl < xybttns[i].rightx) and (yl > xybttns[i].lefty) and (yl < xybttns[i].righty) then
				bttn_new = i
			end
		end
		if (bttn_new ~= bttn_old) then
			barF2_open_array();
			bttn_old = bttn_new
			return;
		end
		
	end
	---locate movement over displayed array ---
	if (bttn_array == true) then
		for i=1,9 do
			if (i ~= 5) then
				if (x > xyarray[i].leftx) and (x < xyarray[i].rightx) and (y > xyarray[i].lefty) and (y < xyarray[i].righty) then
					bttn_enter = i
					getglobal("barF2_Array_" ..i.."Active"):Show();
				elseif (xl > xyarray[i].leftx) and (xl < xyarray[i].rightx) and (yl > xyarray[i].lefty) and (yl < xyarray[i].righty) then
					bttn_enter = i
					getglobal("barF2_Array_" ..i.."Active"):Show();
				else
					getglobal("barF2_Array_" ..i.."Active"):Hide();
				end
			else
				if (x > xyarray[i].leftx) and (x < xyarray[i].rightx) and (y > xyarray[i].lefty) and (y < xyarray[i].righty) then
					bttn_enter = i
				elseif (xl > xyarray[i].leftx) and (xl < xyarray[i].rightx) and (yl > xyarray[i].lefty) and (yl < xyarray[i].righty) then
					bttn_enter = i
				end
			end
		end
		local array_leftx = xyarray[1].leftx
		local array_rightx = xyarray[3].rightx
		local array_lefty = xyarray[1].lefty
		local array_righty = xyarray[9].righty
		if (x > array_leftx) and (x < array_rightx) and (y > array_lefty) and (y < array_righty) then
			return;
		elseif (xl > array_leftx) and (xl < array_rightx) and (yl > array_lefty) and (yl < array_righty) then
			return;
		else
			barF2_close_array();
		end
	end
end
function barF2_open_array()
	barF2_xydata();
	barF2_xydataShow();
	local sc = GetUIScale();
	local focal_sc,focal_sz,focal_startx,focal_starty,bSPACE;
	local focal                                       = bttn_new
	local obj                                         = barF2["layout" ..barF2.GLOBAL.Use].Bttns[focal].parent
	if (obj == "UIParent") then
		focal_sc                                      = barF2["layout" ..barF2.GLOBAL.Use].Bttns[focal].scale
		bSPACE                                        = barF2.GLOBAL.Spacing
		focal_sz                                   	  = (42  + bSPACE) * focal_sc *sc
		focal_startx                                  = xybttns[focal].leftx - focal_sz 
		focal_starty                                  = xybttns[focal].lefty - focal_sz  
	else
		focal_sc                                      = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].scale
		bSPACE                                        = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].Spacing
		focal_sz                                      = (42  + bSPACE) * focal_sc * sc
		focal_startx                                  = xybttns[focal].leftx - focal_sz  
		focal_starty                                  = xybttns[focal].lefty - focal_sz  
	end
	bttn_array                                        = true
	barF2_Array_Frame                                 :Show();
	local cArray,rArray                               = 0,1
	for i = 1,9 do
		cArray = cArray + 1
		if i == 1  or i == 4 or i == 7 then 
			xyarray[i].leftx = focal_startx; 
		elseif i == 2 or i== 5 or i== 8 then
			xyarray[i].leftx = xybttns[focal].leftx
		else
			xyarray[i].leftx = xybttns[focal].leftx + focal_sz
		end;
		if i <4 then
			xyarray[i].lefty = focal_starty
		elseif i >3 and i<7 then
			xyarray[i].lefty = xybttns[focal].lefty
		else
			xyarray[i].lefty = xybttns[focal].lefty + focal_sz
		end;
		xyarray[i].rightx                             = xyarray[i].leftx + focal_sz- 10
		xyarray[i].righty                             = xyarray[i].lefty + focal_sz- 10
		if i ~= 5 then
			getglobal("barF2_Array_"..i)              :SetSize(36 * focal_sc, 36* focal_sc);
			getglobal("barF2_Array_"..i .."Border")   :SetSize(64 * focal_sc, 64 * focal_sc);
			getglobal("barF2_Array_"..i .."Active")   :SetSize(64 * focal_sc, 64 * focal_sc);
			getglobal("barF2_Array_"..i)              :ClearAllAnchors();
			getglobal("barF2_Array_"..i)              :SetAnchor("TOPLEFT","TOPLEFT","UIParent",xyarray[i].leftx/sc,xyarray[i].lefty/sc);
		else 
			getglobal("barF2_Array_"..i)              :Hide();
			getglobal("barF2_"..focal)                :ClearAllAnchors();
			getglobal("barF2_"..focal)                :SetAnchor("TOPLEFT","TOPLEFT","UIParent",xybttns[focal].leftx/sc,xybttns[focal].lefty/sc);
		end
		if cArray == 3 then 
			cArray = 0 
			rArray = rArray + 1
		end
		if obj ~="UIParent" then
			for j=1,80 do
				if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].parent == obj) and ( j ~= barF2.GLOBAL.Shifter ) and ( j ~= focal ) then
					if (i<4) and (math.ceil(xybttns[j].leftx) == math.ceil(xyarray[i].leftx)) and (math.ceil(xybttns[j].lefty) <= math.ceil(xyarray[i].lefty)) then
						--move up
						xybttns[j].lefty = xybttns[j].lefty - focal_sz
						xybttns[j].righty = xybttns[j].righty - focal_sz
					elseif (i == 4) and (math.ceil(xybttns[j].leftx) <= math.ceil(xyarray[i].leftx)) and (math.ceil(xybttns[j].lefty) == math.ceil(xyarray[i].lefty)) then
						--move left
						xybttns[j].leftx = xybttns[j].leftx - focal_sz
						xybttns[j].rightx = xybttns[j].rightx - focal_sz
					elseif (i == 6) and (math.ceil(xybttns[j].leftx) >= math.ceil(xyarray[i].leftx)) and (math.ceil(xybttns[j].lefty) == math.ceil(xyarray[i].lefty)) then
						--move right
						xybttns[j].leftx = xybttns[j].leftx + focal_sz
						xybttns[j].rightx = xybttns[j].rightx + focal_sz
					elseif (i>6) and (math.ceil(xybttns[j].leftx) == math.ceil(xyarray[i].leftx)) and (math.ceil(xybttns[j].lefty) >= math.ceil(xyarray[i].lefty)) then
						--move down
						xybttns[j].lefty = xybttns[j].lefty + focal_sz
						xybttns[j].righty = xybttns[j].righty + focal_sz
					end
				end
			end
			barF2_xydataShow();
		end
	end
end
function barF2_close_array()
	local sc = GetUIScale();
	bttn_array = false
	barF2_Array_Frame:Hide();
	bttn_old = -1
	bttn_new = -1
	bttn_enter = -1
	barF2_xydata();
	barF2_xydataShow();
end
function barF2_Shifter_Empty()
	for i = 1,10 do
		if (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count == 0) then
			group_new = i
			return(group_new);
		end
	end
	group_new=11
	return(group_new);
end
--- Keep groups trimmed from empty x,y start
function barF2_Shifter_group()
	--check for count = 1 to make a non grouping
	for i=1,10 do
		if (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count < 2) then
			local fparent = "barF2_Frame_" ..i
			for j=1,80 do
				if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].parent == fparent) then
					barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].x,barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].y = getglobal("barF2_"..j):GetPos();
					barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].parent = "UIParent"
					barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count   = 0
					barF2["layout" ..barF2.GLOBAL.Use].Bars[i].scale   = 1
					barF2["layout" ..barF2.GLOBAL.Use].Bars[i].show    = false
					getglobal("barF2SHB_" ..i)                  : SetChecked(barF2["layout" ..barF2.GLOBAL.Use].Bars[i].show);
					barF2_ReFresh_Config();
					break;
				end
			end
		end
	end
	--check for size of frame and reduce expand
	for i =1,10 do
		if (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count > 1) then
			local fparent              =               "barF2_Frame_" ..i
			for j=1,80 do
				if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].parent == fparent) then
					if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].x < 1) then
						barF2_squash_x(1,fparent,i);
					end
					if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].y < 1) then
						barF2_squash_y(1,fparent,i);
					end
				end
			end
			local lowest_xcount,lowest_ycount = 0,0
			for j=1,80 do
				if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].parent == fparent) then
					if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].x == 1) then
						lowest_xcount = lowest_xcount+1
					end
					if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[j].y == 1) then
						lowest_ycount = lowest_ycount+1
					end
				end
			end
			if (lowest_xcount == 0) then 
				barF2_squash_x( -1,fparent,i); 
			end
			if (lowest_ycount == 0) then 
				barF2_squash_y(-1,fparent,i); 
			end
		end
	end
	barF2_ReFresh();
	if (barF2.GLOBAL.Mode == "Config") then
		barF2_Count_Tot();
		barF2_Update_Tottext();
	end
end
function barF2_squash_x(space_x,fparent,fparid)
	local sc                   =               GetUIScale();
	local bSc                  =               barF2["layout" ..barF2.GLOBAL.Use].Bars[fparid].scale
	local bSPACE               =               barF2["layout" ..barF2.GLOBAL.Use].Bars[fparid].Spacing
	for k=1,80 do
		if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[k].parent == fparent) then
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[k].x = barF2["layout" ..barF2.GLOBAL.Use].Bttns[k].x + space_x
		end
	end
	barF2["layout" ..barF2.GLOBAL.Use].Bars[fparid].x = barF2["layout" ..barF2.GLOBAL.Use].Bars[fparid].x - (((42 + bSPACE) * bSc * sc) * space_x )
end
function barF2_squash_y(space_y,fparent,fparid)
	local sc                   =               GetUIScale();
	local bSc                  =               barF2["layout" ..barF2.GLOBAL.Use].Bars[fparid].scale
	local bSPACE               =               barF2["layout" ..barF2.GLOBAL.Use].Bars[fparid].Spacing
	for k=1,80 do
		if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[k].parent == fparent) then
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[k].y = barF2["layout" ..barF2.GLOBAL.Use].Bttns[k].y + space_y
		end
	end
	barF2["layout" ..barF2.GLOBAL.Use].Bars[fparid].y = barF2["layout" ..barF2.GLOBAL.Use].Bars[fparid].y - (((42 + bSPACE) * bSc * sc) * space_y)
end
function barF2_StopMoving(this)
	local shifter_swap = 0
	local ind                      = this:GetID();
	local bfUIScale                = GetUIScale();
	local obj                      = barF2["layout" ..barF2.GLOBAL.Use].Bttns[ind].parent
	local bSPACE;
	barF2_Shift_Frame              : Hide();
	if ( not ACTIONBUTTON_LOCKED ) then
		barF2.GLOBAL.Lock = false
	end
	if (bttn_array == true) and (bttn_enter>0) then
		this                       : StopMovingOrSizing();
		obj                        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[bttn_new].parent
		
		local focal_sc,focal_sz,focal_posx,focal_posy,focal_offx,focal_off;
		
		if (obj == "UIParent") then                                                                     --free roaming button join
			bSPACE                 = barF2.GLOBAL.Spacing
			focal_sc               = barF2["layout" ..barF2.GLOBAL.Use].Bttns[bttn_new].scale
			focal_sz               = (42 + bSPACE) * focal_sc                                           --((2*42)-41) * focal_sc
			focal_posx             = barF2["layout" ..barF2.GLOBAL.Use].Bttns[bttn_new].x
			focal_posy             = barF2["layout" ..barF2.GLOBAL.Use].Bttns[bttn_new].y
			focal_offx             = 0
			focal_offy             = 0
			
			if (bttn_enter <4) then
			
				focal_offy         = focal_offy - focal_sz
				if (bttn_enter == 1) then focal_offx = focal_offx - focal_sz end
				if (bttn_enter == 3) then focal_offx = focal_offx + focal_sz end
				
			elseif (bttn_enter == 4)  then
			
				focal_offx         = focal_offx - focal_sz
				
			elseif (bttn_enter == 6)  then
			
				focal_offx         = focal_offx + focal_sz
				
			elseif (bttn_enter >6) then
			
				focal_offy         = focal_offy + focal_sz
				if (bttn_enter == 7) then focal_offx = focal_offx - focal_sz end
				if (bttn_enter == 9) then focal_offx = focal_offx + focal_sz end
				
			end
			-- Is this a new group or maximum groups reached
			local new_group        = barF2_Shifter_Empty();
			
			if new_group >10 then
				barF2["layout" ..barF2.GLOBAL.Use].Bttns[ind].x               = focal_posx + focal_offx
				barF2["layout" ..barF2.GLOBAL.Use].Bttns[ind].y               = focal_posy + focal_offy
			else
				barF2["layout" ..barF2.GLOBAL.Use].Bars[new_group].count      = 1
				barF2["layout" ..barF2.GLOBAL.Use].Bars[new_group].show       = true
				barF2["layout" ..barF2.GLOBAL.Use].Bars[new_group].x          = focal_posx - focal_sc
				barF2["layout" ..barF2.GLOBAL.Use].Bars[new_group].y          = focal_posy - focal_sc
				barF2["layout" ..barF2.GLOBAL.Use].Bars[new_group].scale      = focal_sc
				barF2["layout" ..barF2.GLOBAL.Use].Bars[new_group].row        = 1
				barF2["layout" ..barF2.GLOBAL.Use].Bars[new_group].Spacing    = bSPACE
				barF2["layout" ..barF2.GLOBAL.Use].Bars[new_group].IsPressed  = "Always"
				barF2["layout" ..barF2.GLOBAL.Use].Bttns[bttn_new].x          = 1
				barF2["layout" ..barF2.GLOBAL.Use].Bttns[bttn_new].y          = 1
				barF2["layout" ..barF2.GLOBAL.Use].Bttns[bttn_new].parent     = "barF2_Frame_" .. new_group
				obj = "barF2_Frame_" .. new_group
				selected_bar = new_group
				barF2_ReFresh_Config();
			end
		end
		if (obj ~= "UIParent") then
		
			focal_sc               = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].scale
			bSPACE                 = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].Spacing
			focal_sz               = 1  --(42 + bSPACE) * focal_sc                                  --((2*42)-41) * focal_sc
			focal_posx             = barF2["layout" ..barF2.GLOBAL.Use].Bttns[bttn_new].x
			focal_posy             = barF2["layout" ..barF2.GLOBAL.Use].Bttns[bttn_new].y
			focal_offx             = 0
			focal_offy             = 0
			selected_bar           = getglobal(obj):GetID();
			
			if     (bttn_enter <4)   then
			
				focal_offy         = focal_offy - focal_sz	
				if (bttn_enter == 1) then focal_offx = focal_offx - focal_sz end
				if (bttn_enter == 3) then focal_offx = focal_offx + focal_sz end
				
			elseif (bttn_enter == 4) then
			
				focal_offx         = focal_offx - focal_sz
				
			elseif (bttn_enter == 6) then
			
				focal_offx         = focal_offx + focal_sz
				
			elseif (bttn_enter >6)   then
			
				focal_offy         = focal_offy + focal_sz
				if (bttn_enter == 7) then focal_offx = focal_offx - focal_sz end
				if (bttn_enter == 9) then focal_offx = focal_offx + focal_sz end
				
			end
			-- check to see if a blank space and place without shifting other buttons
			local array_blank = true
			for i =1,80 do	
				if (obj == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].parent) then
					if (barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x == focal_posx + focal_offx) and   (barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y == focal_posy + focal_offy) then
						array_blank = false
						break;
					end
				end
			end
			if (array_blank == false) then
				for i =1,80 do
			
					if (obj == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].parent) then
					
						if (bttn_enter == 1) and (focal_posx - focal_sz == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x) and (focal_posy > barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y) then
							
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y + focal_offy
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x + focal_offx 
					
						elseif (bttn_enter == 2) and (focal_posx == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x) and (focal_posy > barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y) then
					
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y + focal_offy
						
						elseif (bttn_enter == 3) and (focal_posx + focal_sz == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x) and (focal_posy > barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y) then
						
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y + focal_offy
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x + focal_offx 
						
						elseif (bttn_enter == 4) and (focal_posx > barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x) and (focal_posy == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y) then
						
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x + focal_offx 
					
						elseif (bttn_enter == 5) and (bttn_new == i) then
						
							barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].count = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].count - 1
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].parent   = "UIParent"
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x,barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y = GetCursorPos();
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x  = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x -(9 * barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].scale);
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y  = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y -(9 * barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].scale);
							shifter_swap = i
							DEFAULT_CHAT_FRAME                            :AddMessage("Button " ..i .." Picked up please click",1,1,0);
							barF2_StartMoving(getglobal("barF2_" ..i));
					
						elseif (bttn_enter == 6) and (focal_posx < barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x) and (focal_posy == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y) then
						
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x + focal_offx 
						
						elseif (bttn_enter == 7) and (focal_posx - focal_sz == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x) and (focal_posy < barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y) then
						
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y + focal_offy
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x + focal_offx 
					
						elseif (bttn_enter == 8) and (focal_posx == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x) and (focal_posy < barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y) then
						
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y + focal_offy
						
						elseif (bttn_enter == 9) and (focal_posx + focal_sz == barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x) and (focal_posy < barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y) then
						
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y + focal_offy
							barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x        = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x + focal_offx 
					
						end
					
					end
				
				end
			end
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[ind].parent                     = obj
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[ind].x                          = focal_posx + focal_offx
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[ind].y                          = focal_posy + focal_offy
			barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].count    = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(obj):GetID()].count +1
		end
		barF2_ReFresh_Config();
		barF2_close_array();
		barF2_Shifter_group();
	elseif (obj == "UIParent") then
		this:StopMovingOrSizing();
		barF2["layout" ..barF2.GLOBAL.Use].Bttns[ind].x,barF2["layout" ..barF2.GLOBAL.Use].Bttns[ind].y = this:GetPos();
		barF2_Shifter_group();
	else
		getglobal(obj):StopMovingOrSizing();
		ind = getglobal(obj):GetID();
		barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].x,barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].y = getglobal(obj):GetPos();
		if (barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].x<0) then 
			barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].x=1;
		end;
		if (barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].y<0) then 
			barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].y=1 ;
		end;
		selected_bar = ind
	end
	if shifter_swap == 0 then
		barF2.GLOBAL.Shifter = -1
	else
		barF2.GLOBAL.Shifter = shifter_swap
		barF2_Shift_Frame:Show();
	end
	barF2_ReFresh_Config();
	barF2_ReFresh();
end