-----------------------------------------------------------------------
--- 10 Bars  80 buttons   **** barF2 ****   Skinning,Scaling,Strata ---
--- Replace Action Bars   ** by Tatto  **   AutoShow, Show/hide     ---
--- Easy to Use Interface ***************   Buff Showing Buttons    ---
--- Mousewheel scaling                      Right Click to Unbuff   ---
-----------------------------------------------------------------------
------------------------ VERSION 2.04 beta  ---------------------------
---------------------------    MODES    -------------------------------
-----------------------------------------------------------------------

--Total rework of code version --

--Is barf2 ready to proceed with ToonName in place--
local ToonName,ToonClass ;
local barF2_wait = "init"
barF2_Ready = function()
	if UnitName("player") ~= nil then
		ToonName  = UnitName ("player");
		ToonClass = UnitClass("player");
		if (barF2_wait == "loaded") then
			return true;
		else
			return false;
		end
	else
		return false;
	end
end
function barF2_Toon()
	return UnitName("player"),UnitClass("player");
end


---EVENTS Concerning Setting Up Data---
function barF2_OnEvent(this, event)
	if     ( event == "VARIABLES_LOADED" )     and   (barF2_wait ~= "loaded")   then
		barF2_wait = "VARIABLES_LOADED";
		SaveVariables("barF2");
		getglobal("barF2_waiter_please"):Show();
	elseif ( event == "EXCHANGECLASS_SUCCESS")  then
		SaveVariablesPerCharacter("barF2_CHAR");
		ToonName,ToonClass  = barF2_Toon();
		barF2_Name_Class();
		barF2.GLOBAL.Mode = "Normal"
		barF2_wait="loaded"
		barF2_Hotkeys_Layout();
		if barF2_Config_Main_Frame:IsVisible() then
			barF2_ReFresh_Config();
		end
		barF2_ReFresh();
	elseif (event == "LOADING_END")  then
		--getglobal("barF2_Defaultparent"):UnregisterEvent("VARIABLES_LOADED");
		--getglobal("barF2_Defaultparent"):UnregisterEvent("LOADING_END");
	end
end
--- When Variables are loaded start a loop to make sure all data is correctly initialized---
function barF2loop()
	ToonName,ToonClass = barF2_Toon();
	if ToonName ~= nil then
		getglobal("barF2_waiter_please"):Hide();
		barF2_VARS_LOADED();
		barF2_New_Version();
		SaveVariablesPerCharacter("barF2_CHAR");
		barF2_Name_Class();
		getglobal("barF2_Defaultparent"):UnregisterEvent("VARIABLES_LOADED");
		getglobal("barF2_Defaultparent"):UnregisterEvent("LOADING_END");
		barF2.GLOBAL.Mode="Normal"
		barF2_wait="loaded"
		barF2_ReFresh();
		barF2_Hotkeys_Layout();
		DEFAULT_CHAT_FRAME:AddMessage("|cFFFFFF20 barF2 "..barF2.GLOBAL.Version.." |rConfig button on the minimap.", 0.2, 0.5, 0.85);
	else
		return;
	end
end

---v2.04 clean barF2 VARS and make new Global VARS--
barF2_makeGLOBALs = function (value)
	if barF2[value] ~= nil then
		barF2.GLOBAL[value] = barF2[value]
		barF2[value] = nil
	end
end
-- VARAIBLES LOADED --
barF2_VARS_LOADED = function()
	local newto_barF2 = false
	local bttncount   = 0
	local barcount    = 1
	---check to see if first timer--
	if (barF2 == nil)  then 
		local BarF2_ActionBarInfo = {}
		for i = 1,4 do 
			BarF2_ActionBarInfo[i]={["row"] = 5,["count"]=20,["visible"] = false,};
		end
		barF2                                     = nil
		barF2                                     = {}
		newto_barF2                               = true
		barF2["GLOBAL"]                           = {["Mode"] = "Init",   ["Use"]    = 1,    ["Dump"]    = "Empty",      ["Lock"]    = false,
		                                             ["Skin"] = "Syndi_invalid_norm", ["Glossy"] = true, ["Version"] = "v2.04 beta", ["Blank"]   = false,
													 ["Hot"]  = true,     ["Follow"] = false,["Shift"]   = false,        ["Shifter"] = -1,
                                                     ["Spacing"] = 0,													 
		                                            }
		for j=1,6 do
		--layout--
			barcount =1
			barF2["layout" ..j]={}
			barF2["layout" ..j]["Shift"]=false
			barF2["layout" ..j]["Bars"]={}
			for i=1,4 do
				barF2["layout" ..j].Bars[barcount]={["scale"] = 1,  ["count"]  = BarF2_ActionBarInfo[i].count, ["row"]       = BarF2_ActionBarInfo[i].row,
				                                    ["show"] = true,["Spacing"]= 0,                      ["IsPressed"] = "Always",
													                ["x"]      = j * 100,                ["y"]         = i *150,
													}
				barcount=barcount+1
				barF2["layout" ..j].Bars[barcount]={["scale"]=1,    ["count"]=20-BarF2_ActionBarInfo[i].count, ["row"]=20-BarF2_ActionBarInfo[i].count,
				                                    ["show"]= false,["Spacing"] = 0,                     ["IsPressed"] = "Always",
													                ["x"]      = 50,                    ["y"]  = barcount * 25,
				                                    }
				barcount=barcount+1
			end
			for i=barcount,10 do
				barF2["layout" ..j].Bars[i]       ={["scale"]=1,    ["count"]=0,                         ["row"]=0,
                                                    ["show"]= false,["Spacing"] = 0,	                 ["IsPressed"] = "Always",
  								                                    ["x"]=50,                            ["y"]=i * 25,					
				                                   }
			end
			barcount=1
		----now to place buttons within bars for initial look--
		---dummy values first before function to place in bars--
			barF2["layout" ..j]["Bttns"]={}
			for i=1,80 do
				barF2["layout" ..j].Bttns[i]={["parent"] = "UIParent", ["x"] = 50, ["y"] = 50, ["scale"] = 1, ["strata"] = "HIGH"}
			end		
		end
	end
	---Convert pre version 2.04 to New--
	if (barF2.Use ~= nil) then
		local barF2_Ele ={"Version","Shift","Dump","Use","Glossy","Mode","Lock","Hot","Tooltip","Skin","Shifter","Spacing","Blank","Follow"}
		barF2["GLOBAL"] = {};
		for i,v in pairs(barF2_Ele) do
			barF2_makeGLOBALs(v);
		end
	end
	--barF2_makeGLOBALs = nil
	barF2_wait          = "barF2_VARS_LOADED_end"
	barF2.GLOBAL.Mode   = "Normal"
	ACTIONBUTTON_LOCKED = barF2.GLOBAL.Lock
end




barF2_New_Version = function()
-- v2.00 barF2 Modes --
	if (barF2.GLOBAL["Shift"] == nil ) then
		barF2.GLOBAL["Shift"] = false
		barF2.GLOBAL["Shifter"] = -1
		for i =1,6 do
			barF2["layout"..i]["Shift"]=false
		end
	end
	if (barF2.GLOBAL["Spacing"] == nil) then
		barF2.GLOBAL["Spacing"] = 0
		for i = 1,6 do
			for j = 1,10 do
				barF2["layout"..i].Bars[j]["Spacing"] = 0
				barF2["layout"..i].Bars[j]["IsPressed"] = "Always"
			end
		end
	end
	-- v2.02 follow to use action --
	if (barF2.GLOBAL["Follow"] == nil) then
		barF2.GLOBAL["Follow"] = false
	end
	-- v2.04 Tooltip setup changed to here --
	if not(barF2.GLOBAL.Tooltip) then
		barF2.GLOBAL["Tooltip"]={["Mode"] = false, ["Position"] = {["x"] = 50,["y"] =50}}
	end
	-- v2.04 Clear points data --
	local UIsc = GetUIScale();
	if (barF2["layout1"].Bars[1]["point"] ~= nil ) then
		for i = 1,6 do
			for j = 1,10 do
				barF2["layout" ..i].Bars[j]["point"] = nil
				barF2["layout" ..i].Bars[j]["RPoint"]= nil
				---convert all x,y settings to non UIscaled
				barF2["layout" ..i].Bars[j].x        = barF2["layout" ..i].Bars[j].x * UIsc
				barF2["layout" ..i].Bars[j].y        = barF2["layout" ..i].Bars[j].y * UIsc
			end
			for j = 1,80 do
				if barF2["layout"..i].Bttns[j].parent == "UIParent" then
					barF2["layout" ..i].Bttns[j].x       = barF2["layout" ..i].Bttns[j].x * UIsc
					barF2["layout" ..i].Bttns[j].y       = barF2["layout" ..i].Bttns[j].y * UIsc
				end
			end
		end
	end
		
	barF2.GLOBAL.Shift = barF2["layout" ..barF2.GLOBAL.Use].Shift
	barF2.GLOBAL.Version="v2.07 beta"
	barF2_wait = "barF2_New_Version_end"	
end
---Name / Class --
function barF2_Name_Class()
	if (barF2_CHAR == nil ) then
		barF2_CHAR = {}
	end
	--v2.04--
	if  (barF2_CHAR[ToonName] == nil ) then
		barF2_CHAR[ToonName] = {};
	end
	if (barF2[ToonName] ~= nil) then
		barF2_CHAR[ToonName] = barF2[ToonName]
		barF2[ToonName] = nil
	end
	if  (barF2_CHAR[ToonName][ToonClass] == nil ) then
		barF2_CHAR[ToonName][ToonClass]={["Skin"] = "Syndi_invalid_norm", ["Use"] = 1, ["Glossy"] = true, ["FIX"] = true};
		for i = 1,80 do
			barF2_CHAR[ToonName][ToonClass][i] = {["show"] = true,["autohide"] = false, ["skin"] = "Main", ["gloss"] = false}
		end
	elseif (barF2_CHAR[ToonName][ToonClass].FIX == nil) then               -- v2.05 fix for buttons when passive hide blanks is active storing info wrong
		barF2_CHAR[ToonName][ToonClass]["FIX"] = true
		if barF2.GLOBAL.Blank == true then
			for i =1,80 do barF2_CHAR[ToonName][ToonClass][i].show = true end;
		end
	end
	barF2.GLOBAL.Skin   = barF2_CHAR[ToonName][ToonClass].Skin
	barF2.GLOBAL.Use    = barF2_CHAR[ToonName][ToonClass].Use
	barF2.GLOBAL.Glossy = barF2_CHAR[ToonName][ToonClass].Glossy
	if (barF2_wait ~= "loaded") then 
		barF2_wait = "barF2_Name_Class_end";
	end
end