local ToonName,ToonClass;
local selected_bar,selected_button;
local bttn_Count ;


--SLIDERS--
function barF2_Slider_Load(this)
	local id = this:GetID();
	local MIN,MAX,STEP,LABEL = 0,0,"";
	this.loading=1;
	if id >0 and id<21 then              --count/row
		MIN,MAX,STEP =   0,  20, "INT";
		if id<11 then LABEL=" Count" else LABEL="  Row" end
	elseif id > 30 and id < 33 then      --31 bar 32 button -Scale
		MIN,MAX,STEP,LABEL = 0.5, 1.5, "FLT","scale";
	elseif id > 40 and id < 43 then      --41 bar 42 defualt-Spacing
		MIN,MAX,STEP,LABEL =  -4,  50, "INT","spacing";
	elseif id == 99 then                   -- Layout
		MIN,MAX,STEP,LABEL =   1,   6, "INT"," Layout";
	end
	
	this                                    :SetValueStepMode(STEP);
	this                                    :SetMinMaxValues(MIN,MAX);
	getglobal(this:GetName().."LeftText") :SetText(MIN.."   "..LABEL);
	getglobal(this:GetName().."RightText"):SetText(""..MAX);
	this.loading=0;
end
function barF2_Slider_ValueChange(this)
	local id = this:GetID();
	local Value = this:GetValue();
	selected_bar,selected_button=barF2_GetSelected();
	
	if id > 0 and id < 21 then
		barF2_Count_Row(this,id);
		if id<11 then barF2_Config_EnterBar(getglobal("barF2BKG_"..id)) else barF2_Config_EnterBar(getglobal("barF2BKG_"..id-10)) end
	elseif id == 31 then           -- Scale bar/group
		barF2["layout"..barF2.GLOBAL.Use].Bars[selected_bar].scale = Value;
		getglobal(this:GetName() .."Text"):SetText(string.format("%.2f",Value));
		barF2_place();
	elseif id == 32 then           -- Scale Button
		barF2["layout"..barF2.GLOBAL.Use].Bttns[selected_button].scale = Value;
		getglobal(this:GetName() .."Text"):SetText(string.format("%.2f",Value));
		barF2_Bttn_Scale(selected_button,Value);
	elseif id == 41 then           -- bar/group spacing
		barF2["layout"..barF2.GLOBAL.Use].Bars[selected_bar].Spacing = Value;
		getglobal(this:GetName() .."Text"):SetText(Value);
		barF2_place();
	elseif id == 42 then           -- Default spacing for group mode when creating groups
		barF2.GLOBAL.Spacing = Value;
		getglobal(this:GetName() .."Text"):SetText(Value);
	elseif id == 99 then           -- Layout slider
		ToonName,ToonClass = barF2_Toon();
		getglobal(this:GetName() .."Text"):SetText(Value);
		barF2.GLOBAL.Use = Value;
		barF2_CHAR[ToonName][ToonClass].Use = Value;
		barF2_Reset_Selected();
		selected_bar,selected_button = barF2_GetSelected();
		barF2_Config_Bar_Frame:Hide();
		barF2_Config_Button_Frame:Hide();
		barF2_ReFresh_Config();
		barF2_Hotkeys_Layout();
		barF2_ReFresh();
	end
end

function barF2_Count_Row(this,id)
	if not this:IsVisible() then
		return;
	end
	local Value = this : GetValue();
	bttn_Count = barF2_Count_Tot();
	--Rows--
	if id>10 then
		id = id - 10
		if (Value > barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count) then
			barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row  =  barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count;
			this : SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row);	
		else
			barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row  = Value;
		end
		
		if (Value == 0) and (barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count~=0) then
			barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row  = 1;
			this  : SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row);
		end
		getglobal(this:GetName() .."Text")  : SetText(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row);
		
	else
	--Count--
		if (Value > barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count) then
			if bttn_Count == 80 then
				this  : SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count);
			else
				barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count = Value;
				barF2_Count_Tot();
				if bttn_Count > 80 then
					barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count   = barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count - (bttn_Count-80);
					this  : SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count);
				end
			end
		else
			barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count = Value
		end
		
		getglobal(this:GetName() .."Text")   : SetText(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count);
		
		if (barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count < barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row) then
			barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row   =   barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count;
			getglobal("barF2RW_" ..id .."Text")  : SetText(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row);
			getglobal("barF2RW_" ..id)            : SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row);
		end
		
		if ( barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row == 0 ) and ( barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count ~= 0 ) then
			barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row   =  1;
			getglobal("barF2RW_" ..id)     :   SetValue(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row);
			getglobal("barF2RW_" ..id .."Text")   : SetText(barF2["layout" ..barF2.GLOBAL.Use].Bars[id].row);
		end
		
		if ( barF2["layout" ..barF2.GLOBAL.Use].Bars[id].count == 0 ) then
			barF2["layout" ..barF2.GLOBAL.Use].Bars[id].show = false;
			getglobal("barF2SHB_" ..id)  : SetChecked(false);
		end
	end
	
	barF2_SortButtons_Bars();
	barF2_place();
	barF2_ShowNumbers();
	barF2_Update_Tottext();
end

-- TICKBOXES--
function barF2_Tick_Box(this)
	local id = this:GetID();
	selected_bar,selected_button=barF2_GetSelected();
	ToonName,ToonClass = barF2_Toon();
	
	if id > 20 and id <31 then                  	-- Show bar/Group
		if (barF2["layout" ..barF2.GLOBAL.Use].Bars[id - 20].count<1) then
			this:SetChecked(false);
			return;
		end
		barF2["layout"..barF2.GLOBAL.Use].Bars[id-20].show = this:IsChecked();
		barF2_place();
		barF2_Config_EnterBar(getglobal("barF2BKG_"..id-20));
	elseif id == 91 then                           -- Hide Blanks unUsed Buttons passive
		barF2.GLOBAL.Blank  = this:IsChecked();
		for i = 1,80 do
			if not (HasAction(i)) and (barF2.GLOBAL.Blank == true) then
				getglobal("barF2_" ..i):Hide();
			elseif (HasAction(i)) and (barF2.GLOBAL.Blank == true) and (barF2_CHAR[ToonName][ToonClass][i].show == true) then
				getglobal("barF2_" ..i):Show();
			end
		end
		barF2_ReFresh_Config();
	elseif id == 92 then                           -- Show Binding Text on Buttons
		barF2.GLOBAL.Hot  =  this:IsChecked();
		barF2_place();
	elseif id == 93 then                           -- Lock Skills in buttons from being dragged
		barF2.GLOBAL.Lock = this:IsChecked();
		ACTIONBUTTON_LOCKED = this:IsChecked();
	elseif id == 94 then                           -- Show Gloss on Main Skin
		barF2.GLOBAL.Glossy = this:IsChecked();
		if (barF2.GLOBAL.Skin == "boring") and (barF2.GLOBAL.Glossy==true) then
			barF2.GLOBAL.Glossy = false
			this:SetChecked(false);
		end
		barF2_CHAR[ToonName][ToonClass].Glossy = barF2.GLOBAL.Glossy
		barF2_SkinDisp();
	elseif id == 95 then                           -- Show/Hide Button
		barF2_CHAR[ToonName][ToonClass][selected_button].show = this:IsChecked();
		barF2_place();
	elseif id == 96 then                           -- Auto Hide button
		barF2_CHAR[ToonName][ToonClass][selected_button].autohide = this:IsChecked();
		barF2_place();
	elseif id == 97 then                           -- Gloss Button
		if barF2_CHAR[ToonName][ToonClass][selected_button].skin == "boring" then
			this:SetChecked(false);
			return;
		end
		if barF2_CHAR[ToonName][ToonClass][selected_button].skin == "Main" then
			this:SetChecked(barF2.GLOBAL.Glossy);
			return;
		end
		barF2_CHAR[ToonName][ToonClass][selected_button].gloss = this:IsChecked();
		barF2_SkinDisp();
	elseif id == 88 then                           -- Tooltip positioner on/off
		barF2.GLOBAL.Tooltip.Mode = this:IsChecked();
	elseif id == 89 then                           -- Group Mode on/off
		barF2["layout"..barF2.GLOBAL.Use].Shift = this:IsChecked();
		barF2_ReFresh();
		barF2_ReFresh_Config();
	end
end

--MENU BUTTONS CLICKED--
function barF2_ClickedButton_Config(this)
	local id = this:GetID();
	selected_bar,selected_button = barF2_GetSelected();
	ToonName,ToonClass = barF2_Toon();
	
	if id == 71 then                  --Clear Bindings Button
		barF2_Binding_Clear();
	elseif id == 72 then              -- Show All Buttons Now
		for i = 1,10 do
			if (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count ~= 0) then
				barF2["layout" ..barF2.GLOBAL.Use].Bars[i].show = true
				getglobal("barF2SHB_"..i):SetChecked(true);
			else
				barF2["layout" ..barF2.GLOBAL.Use].Bars[i].show = false
			end
		end
		for i = 1,80 do
			barF2_CHAR[ToonName][ToonClass][i].show = true
		end
		barF2.GLOBAL.Blank = false
		getglobal("barF2_HideBlank_Box"):SetChecked(false);
		barF2_place();	
	elseif id == 73 then              -- Hide All Unused Buttons Now
		for i = 1,80 do
			if not HasAction(i) then
				barF2_CHAR[ToonName][ToonClass][i].show = false
			end
		end
		barF2.GLOBAL.Blank = false
		getglobal("barF2_HideBlank_Box"):SetChecked(false);
		barF2_place();	
	elseif id == 74 then              -- Position Tooltip Button
		if (barF2_Sticky_Frame:IsVisible()) then
			barF2_Sticky_Frame:Hide();
		else
			barF2_Sticky_Frame:Show();
			barF2_Sticky_Frame:ClearAllAnchors();
			barF2_Sticky_Frame:SetAnchor("TOPLEFT","TOPLEFT","UIParent",barF2.GLOBAL.Tooltip.Position.x,barF2.GLOBAL.Tooltip.Position.y)
		end
	elseif id == 75 then              -- Save Tooltips position
		barF2.GLOBAL.Tooltip.Position.x,barF2.GLOBAL.Tooltip.Position.y = barF2_Sticky_Frame:GetPos();
		local USc = GetUIScale();
		barF2.GLOBAL.Tooltip.Position.x = barF2.GLOBAL.Tooltip.Position.x / USc;
		barF2.GLOBAL.Tooltip.Position.y = barF2.GLOBAL.Tooltip.Position.y / USc;
		barF2_Sticky_Frame:Hide();
	elseif id == 76 then              -- Open/Close Extras Menu
		if barF2_Config_Extras_Frame:IsVisible() then
			barF2_Config_Extras_Frame:Hide();
		else
			barF2_Config_Extras_Frame:Show();
		end
	end
end

-- DROP DOWN MENUS--

-- Strata Drop Down Menu
local barF2Strata ={"MEDIUM","HIGH","DIALOG"};
function barF2_ButtonStrata_Menu_init()
	selected_bar,selected_button = barF2_GetSelected();
	local id = 0
	for i,s in pairs(barF2Strata) do
		if s == barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].strata then id = i end
		UIDropDownMenu_AddButton({["text"]=s,["func"]=barF2_ButtonStrata_Menu_click});
	end
	UIDropDownMenu_SetSelectedID(barF2_ButtonStrata_Menu_DropDown,id);
end
function barF2_ButtonStrata_Menu_click(selection)      
	UIDropDownMenu_SetSelectedID(barF2_ButtonStrata_Menu_DropDown,selection:GetID());
	barF2["layout" ..barF2.GLOBAL.Use].Bttns[selected_button].strata   = UIDropDownMenu_GetText(barF2_ButtonStrata_Menu_DropDown);
	barF2_ReFresh();
end
-- Main Skin Drop Down Menu
local barF2_MainSkins_List={}
barF2_MainSkins_List=dofile("Interface\\addons\\barF2\\Graphics\\Skins_list.lua");
function barF2_MainSkin_Menu_init()
	local id = 0
	for i,s in pairs(barF2_MainSkins_List) do
		if s == barF2.GLOBAL.Skin then id = i end
		UIDropDownMenu_AddButton({["text"]=s,["func"]=barF2_MainSkin_Menu_click});
	end
	UIDropDownMenu_SetSelectedID(barF2_MainSkin_Menu_DropDown,id);
end
function barF2_MainSkin_Menu_click(selection)
	ToonName ,ToonClass                =barF2_Toon();       
	UIDropDownMenu_SetSelectedID(barF2_MainSkin_Menu_DropDown,selection:GetID());
	barF2_CHAR[ToonName][ToonClass].Skin    = UIDropDownMenu_GetText(barF2_MainSkin_Menu_DropDown);
	barF2.GLOBAL.Skin              = UIDropDownMenu_GetText(barF2_MainSkin_Menu_DropDown);
	barF2_SkinDisp();
	barF2_ReFresh_Config();
end
--Buttons Skin Drop Down Menu
local barF2_BttnSkins_List={}
barF2_BttnSkins_List=dofile("Interface\\addons\\barF2\\Graphics\\Skins_list.lua");
table.insert(barF2_BttnSkins_List,1,"Main");
function barF2_ButtonSkin_Menu_init()
	ToonName,ToonClass = barF2_Toon();
	selected_bar,selected_button = barF2_GetSelected();
	local id = 0
	for i,s in pairs(barF2_BttnSkins_List) do
		if s == barF2_CHAR[ToonName][ToonClass][selected_button].skin then id = i end
		UIDropDownMenu_AddButton({["text"]=s,["func"]=barF2_ButtonSkin_Menu_click});
	end
	UIDropDownMenu_SetSelectedID(barF2_ButtonSkin_Menu_DropDown,id);
end
function barF2_ButtonSkin_Menu_click(selection)
	ToonName,ToonClass = barF2_Toon();
	selected_bar,selected_button = barF2_GetSelected();
	UIDropDownMenu_SetSelectedID(barF2_ButtonSkin_Menu_DropDown,selection:GetID());
	barF2_CHAR[ToonName][ToonClass][selected_button].skin = UIDropDownMenu_GetText(barF2_ButtonSkin_Menu_DropDown);
	barF2_SkinDisp();
end
-- Display when pressed or always show ..Drop Down Menu
local barF2IsPressed ={"Always","Shift","Alt","Ctrl"};
function barF2_BarIsPressed_Menu_init()
	selected_bar,selected_button = barF2_GetSelected();
	local id = 0
	for i,s in pairs(barF2IsPressed) do
		if s == barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].IsPressed then id = i end
		UIDropDownMenu_AddButton({["text"]=s,["func"]=barF2_BarIsPressed_Menu_click});
	end
	UIDropDownMenu_SetSelectedID(barF2_BarIsPressed_Menu_DropDown,id);
end
function barF2_BarIsPressed_Menu_click(selection)
	selected_bar,selected_button = barF2_GetSelected();
	UIDropDownMenu_SetSelectedID(barF2_BarIsPressed_Menu_DropDown,selection:GetID());
	barF2["layout" ..barF2.GLOBAL.Use].Bars[selected_bar].IsPressed = UIDropDownMenu_GetText(barF2_BarIsPressed_Menu_DropDown);
end
--Group Skin Drop Down Menu
local barF2_GroupSkins_List={}
for i,s in pairs(barF2_BttnSkins_List) do
	table.insert(barF2_GroupSkins_List,s)
	if (s ~= "boring") then
		table.insert(barF2_GroupSkins_List,s ..": Gloss")
	end
end
function barF2_BarSkin_Menu_init()
	for i,s in pairs(barF2_GroupSkins_List) do UIDropDownMenu_AddButton({["text"]=s,["func"]=barF2_BarSkin_Menu_click}); end
end
function barF2_BarSkin_Menu_click(selection)
	UIDropDownMenu_SetSelectedID(getglobal("barF2_BarSkin_Menu_DropDown"),selection:GetID());
	ToonName,ToonClass = barF2_Toon();
	selected_bar,selected_button = barF2_GetSelected();
	local bskin = UIDropDownMenu_GetText(barF2_BarSkin_Menu_DropDown);
	local bskinG = false
	if string.find(bskin,"Gloss") then
		local gs,gf = string.find(bskin,":")
		bskin = string.sub(bskin,1,gs-1)
		bskinG = true
	end
	for i =1,80 do
		if (barF2["layout"..barF2.GLOBAL.Use].Bttns[i].parent == "barF2_Frame_"..selected_bar) then
			barF2_CHAR[ToonName][ToonClass][i].skin = bskin
			barF2_CHAR[ToonName][ToonClass][i].gloss = bskinG
		end
	end
	barF2_SkinDisp();
	barF2_place();
	barF2_ReFresh_Config();
end