local ToonName,ToonClass;
-----Initial set up -----

local buffmatch = 0

--- bFbttnbase is database that when ever a buff check for action required, rather than checking everything again if match proceed
local bFbttnbase ={}
for i = 1,80 do
	bFbttnbase[i]={["icon"] = "empty",["name"] = "empty",["FLASH"] = false};
end
--- get the button id ---
function barF2_GetButtonID(this)
	return this:GetID();
end
--- Button Events --
function barF2_Button_OnEvent(this, event)
	if barF2_Ready() == true then
		if ( event == "ACTIONBAR_SLOT_CHANGED" ) then
			--if ( arg1 == barF2_GetButtonID(this) ) then
				barF2_Button_Update(this);
			--end
		elseif ( event == "PLAYER_BAG_CHANGED" ) then
			barF2_Button_Update(this);
		elseif ( event == "ACTIONBAR_UPDATE_COOLDOWN" ) then
			barF2_Button_UpdateCooldown(this);
		elseif ( event == "PLAYER_INVENTORY_CHANGED" ) then
			barF2_Button_Update(this);
		elseif ( event == "UPDATE_BINDINGS" ) then
			barF2_UpdateHotkeys(this);
		elseif ( event == "CURSOR_ITEM_UPDATE" ) then
			barF2_UpdateBorder(this);
		end
	end
end

function barF2_Button_Update(this)
	if (ToonName == nil) then
		ToonName, ToonClass = barF2_Toon();
	end
	if (ToonName ~= nil) then
		local barF2btSkin = barF2_CHAR[ToonName][ToonClass][barF2_GetButtonID(this)].skin
		if (barF2btSkin == "Main") then
			barF2btSkin = barF2.GLOBAL.Skin
		end
		local icon = getglobal(this:GetName().."Icon");
		local texture, name, count, locked, wore, continued = GetActionInfo(barF2_GetButtonID(this));
	-- if an item being worn like leggings or weapon for example--
		if ( wore ) then
			getglobal(this:GetName().."Border"):SetTexture("Interface\\addons\\barF2\\Graphics\\boring\\Normal2.tga");
		elseif (barF2btSkin == "boring") then
			getglobal(this:GetName().."Border"):SetTexture("Interface\\addons\\barF2\\Graphics\\boring\\Normal.tga");
		elseif (barF2btSkin ~= "boring") then
			getglobal(this:GetName().."Border"):SetTexture("Interface\\addons\\barF2\\Graphics\\" ..barF2btSkin .."\\Normal.tga")
		end
		if ( continued ) then
			getglobal(this:GetName().."Continued"):Show();
		else
			getglobal(this:GetName().."Continued"):Hide();
		end
		if ( texture ) then
			icon:Show();
			icon:SetTexture(texture);
		elseif (barF2btSkin == "boring") then
			icon:Show();
			icon:SetTexture("Interface\\Buttons\\QuickSlot-Normal");
		else
			icon:Hide();
		end	
		SetItemButtonCount(this, count);
		SetItemButtonLuminance(this, count == 0);
		barF2_Button_UpdateCooldown(this);
		--barF2_UpdateBorder(this);
	end
end
function barF2_UpdateBorder(this)
	local ind = this:GetID();
	ToonName,ToonClass = barF2_Toon();
	if ToonName~=nil then
		local obj = barF2["layout" ..barF2.GLOBAL.Use].Bttns[ind].parent
		if (CursorHasItem()) then
			if (obj == "UIParent") and (barF2_CHAR[ToonName][ToonClass][ind].show == true) then
				this:Show();
				this:SetAlpha(1.0)
			elseif obj ~= "UIParent" then
				local bar = getglobal(obj):GetID();
				if barF2["layout"..barF2.GLOBAL.Use].Bars[bar].show == true and barF2_CHAR[ToonName][ToonClass][ind].show  == true then
					this:Show();
					this:SetAlpha(1.0)
				end
			end
			local btnx,btny=this:GetPos();
			if (btnx<0) and (barF2_CHAR[ToonName][ToonClass][ind].autohide == true) then
				this:ClearAllAnchors();
				barF2_UI_pos(this);
			end
		else
			
		end
	end
end
--button OnUpdate--
function BarF2_Frame_OnUpdate(this, elapsedTime)
	local bPosx,bPosy;
	if ToonName == nil then
		if barF2_Ready() == true then
			ToonName,ToonClass = barF2_Toon();
		end
	end
	this.update = this.update - elapsedTime;
	if (ToonName ~= nil) then
		if (this.update<0) then this.update = 2 end
			local i=barF2_GetButtonID(this);
			if (HasAction(i)) then
				local usable = GetActionUsable(i);
				local btnx,btny=this:GetPos();
				if ( usable ) then
					if (getglobal("barF2_" ..i .."Invalid"):IsVisible()) then
						getglobal("barF2_" ..i .."Invalid"):Hide();
					end
					if (barF2_CHAR[ToonName][ToonClass][i].autohide == true) and (btnx<0) then
						getglobal("barF2_" ..i):ClearAllAnchors();
						barF2_UI_pos(this);		
					end
				else
					if not(getglobal("barF2_" ..i .."Invalid"):IsVisible()) then
						getglobal("barF2_"..i .."Invalid"):Show();
					end
					if (barF2_CHAR[ToonName][ToonClass][i].autohide == true) and (btnx>0) then
						getglobal("barF2_" ..i):ClearAllAnchors();
						getglobal("barF2_" ..i):SetAnchor("TOPLEFT","TOPLEFT","UIParent",-100,-100)
					end
				end
				BuffbarF2(this);
				if (buffmatch == 0 and getglobal("barF2_" ..i .."Active"):IsVisible()) then
					getglobal("barF2_" ..i .."Active"):Hide();
				elseif (buffmatch ~= 0 ) and (bFbttnbase[i].FLASH == false) then
					if not (getglobal("barF2_" ..i .."Active"):IsVisible()) then
						getglobal("barF2_" ..i .."Active"):Show();
						getglobal("barF2_" ..i .."Active"):SetAlpha(1);
					end
				elseif (buffmatch ~= 0 ) and (bFbttnbase[i].FLASH == true) then
					if not (getglobal("barF2_" ..i .."Active"):IsVisible()) then
						getglobal("barF2_" ..i .."Active"):Show();
						getglobal("barF2_" ..i .."Active"):SetAlpha(1);
					end
					local buff_phase = this.update - 1 
					if (buff_phase<0) then
						getglobal("barF2_" ..i .."Active"):SetAlpha(1-this.update);
					else
						getglobal("barF2_" ..i .."Active"):SetAlpha(buff_phase);
					end
				end
			else
				if (getglobal("barF2_" ..i .."Invalid"):IsVisible()) then
					getglobal("barF2_" ..i .."Invalid"):Hide();
				end
				if (getglobal("barF2_" ..i .."Active"):IsVisible()) then
					getglobal("barF2_" ..i .."Active"):Hide();
				end
				if (barF2.GLOBAL.Blank == true) and (this:IsVisible()) then
					this:Hide();
				end
			end
	end
end
--is pressed mode--
function barF2_Frame_IsPressed(this)
	--local ind = this:GetID();
	for ind = 1,10 do
		local frame = getglobal("barF2_Frame_"..ind)
		if (frame:IsVisible()) then
			local bFrx,bFry = frame:GetPos();
			if (ToonName ~= nil) then
				if (barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].IsPressed ~= "Always") then
					if (IsShiftKeyDown()) and (barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].IsPressed == "Shift") and (bFrx<0) then
						frame:ClearAllAnchors();
						barF2_UI_pos(frame);
					elseif (IsAltKeyDown()) and (barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].IsPressed == "Alt") and (bFrx<0) then
						frame:ClearAllAnchors();
						barF2_UI_pos(frame);
					elseif (IsCtrlKeyDown()) and (barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].IsPressed == "Ctrl") and (bFrx<0) then
						frame:ClearAllAnchors();
						barF2_UI_pos(frame);
					elseif not(IsShiftKeyDown()) and not(IsCtrlKeyDown()) and not(IsAltKeyDown()) and (bFrx>0) then
						frame:ClearAllAnchors();
						frame:SetAnchor("TOPLEFT","TOPLEFT","UIParent",-600,-500);
					end
				elseif (bFrx< -200) then
					frame:ClearAllAnchors();
					barF2_UI_pos(frame);
				end
			end
		end
	end
end
-- buff check --
function BuffbarF2(this)
	local ind = this:GetID();
	if (ToonName ~= nil) and (HasAction(ind)) then
		buffmatch = 0;
		local texture, name, count, locked, wore, continued = GetActionInfo(ind);
		local bBuffbarF2 = "empty"
		if (texture ~= bFbttnbase[ind].icon) then
			bFbttnbase[ind].icon = texture
			for tab=1,4 do
				for book_slot=1,50 do
					local name, _1, icon, _2, rank, _3, tp_to_upgrade, energy_type, usable = GetSkillDetail(tab, book_slot);
					if not name or not usable then
						break;
					end
					if (texture == icon) and (_2~=2) then
						bBuffbarF2 = name 
						bFbttnbase[ind].name = name
						break;
					end
				end
				if (bBuffbarF2 ~= "empty") then
					break;
				end
			end
			if (bBuffbarF2 == "empty") then
				for aslot=1,90 do
					if (GetBagItemInfo(aslot)) then
						local index,file,name,itemCount,locked,invalid = GetBagItemInfo(aslot);
						if (texture == file) then
							bBuffbarF2 = name 
							bFbttnbase[ind].name = name
							break;
						end
					end
				end	
			end
		else
			bBuffbarF2 = bFbttnbase[ind].name
		end
		if bBuffbarF2 == "empty" then
			bFbttnbase[ind].name = "empty"
			return;
		end
		-------All the above just to get name to check against buff -------
		for i = 1, 40 do
			local buff = UnitBuff("player", i)
			if (buff ~= nil) then
				if (string.find(buff,bBuffbarF2) ~= nil) then
					local buff_st,buff_fin = string.find(buff,bBuffbarF2);
					if buff_st == 1 then
						if (UnitBuffLeftTime("player",i)) then
							local buff_leftTime = UnitBuffLeftTime("player", i);
							if (buff_leftTime < 6) then 
								bFbttnbase[ind].FLASH = true
							else
								bFbttnbase[ind].FLASH = false
							end
						end
						buffmatch = i;
						return;
					end
				end
			end
		end
		bFbttnbase[ind].FLASH = false
	else
		bFbttnbase[ind].name = "empty"
		bFbttnbase[ind].icon = "empty"
	end
end
--button is clicked
function barF2_Bttn_Click(this,key)
	if ( CursorHasItem() ) then
		PickupAction(barF2_GetButtonID(this));
	elseif (key == "LBUTTON")  then
		UseAction(barF2_GetButtonID(this));
	elseif (key == "RBUTTON" ) then
		BuffbarF2(this);
		if (buffmatch~=0) then
			CancelPlayerBuff(buffmatch);
		else
			UseAction(barF2_GetButtonID(this));
		end
	end
end
--Tooltips  on buttons--
function barF2_Tooltip(this)
	GameTooltip:ClearAllAnchors();
	local ind = this:GetID();
	if (barF2.GLOBAL.Tooltip) then
		if (barF2.GLOBAL.Tooltip.Mode == true) then
			GameTooltip:SetAnchor("TOPLEFT", "TOPLEFT", "UIParent",barF2.GLOBAL.Tooltip.Position.x, barF2.GLOBAL.Tooltip.Position.y );
		else
			GameTooltip:SetOwner(this,"ANCHOR_TOPLEFT",-5,0);
		end
	else
		GameTooltip:SetOwner(this,"ANCHOR_TOPLEFT",-5,0);
	end
	GameTooltip:SetActionItem(barF2_GetButtonID(this));
	if (barF2.GLOBAL.Mode == "Config") then 
		GameTooltip:AddLine("USE RIGHT MOUSE BUTTON ",1,1,0); 
		GameTooltip:AddLine("and HOLD for group mode",1,1,0);
	end
end
