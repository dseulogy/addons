local ToonName,ToonClass = "",""
-- ReFresh barF2 displays --
function barF2_ReFresh()
	barF2_SortButtons_Bars();
	barF2_place();
	barF2_SkinDisp();
	barF2_ShowNumbers();
	return;
end
--using macro to change layout--
function UsebarF2(layout)
	layout = math.ceil(tonumber(layout))
	if (layout<1) or (layout>6) then
		DEFAULT_CHAT_FRAME:AddMessage("ERROR not a valid layout", 0.2, 0.5, 0.85);
		return;
	end
	barF2.GLOBAL.Use = layout
	barF2_CHAR[ToonName][ToonClass]["Use"] = barF2.GLOBAL.Use
	barF2_Hotkeys_Layout();
	barF2_ReFresh();
	barF2_ReFresh_Config();
end
--using minimap button to change layout--
function barF2_Mini_Tooltip(this,delta)
	ToonName,ToonClass = barF2_Toon();
	delta = delta / math.abs(delta);
	barF2.GLOBAL.Use = barF2.GLOBAL.Use + delta
	if (barF2.GLOBAL.Use<1) then barF2.GLOBAL.Use=6 end
	if (barF2.GLOBAL.Use>6) then barF2.GLOBAL.Use=1 end
	barF2_CHAR[ToonName][ToonClass]["Use"] = barF2.GLOBAL.Use
	barF2_ReFresh();
	GameTooltip:Hide();
	barF2_MiniTool(this);
	barF2_ReFresh_Config();
end
--Convert button data to position on screen
function barF2_UI_pos(frame)
	local id     = frame:GetID();
	local UIsc   = GetUIScale();
	local parent = "UIParent"
	local x,y;
	if (frame:GetName() == "barF2_" ..id) then
		parent= barF2["layout" ..barF2.GLOBAL.Use].Bttns[id].parent
		if parent == "UIParent" then
			x =  barF2["layout" ..barF2.GLOBAL.Use].Bttns[id].x / UIsc
			y =  barF2["layout" ..barF2.GLOBAL.Use].Bttns[id].y / UIsc
		else
			local bSPACE = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(parent):GetID()].Spacing
			local bSc    = barF2["layout" ..barF2.GLOBAL.Use].Bars[getglobal(parent):GetID()].scale
			x   = ((barF2["layout" ..barF2.GLOBAL.Use].Bttns[id].x *(42+bSPACE))-(41+bSPACE)) * bSc
			y   = ((barF2["layout" ..barF2.GLOBAL.Use].Bttns[id].y *(42+bSPACE))-(41+bSPACE)) * bSc
		end
	else
		x =  barF2["layout" ..barF2.GLOBAL.Use].Bars[id].x / UIsc
		y =  barF2["layout" ..barF2.GLOBAL.Use].Bars[id].y / UIsc
	end
	frame:SetAnchor("TOPLEFT","TOPLEFT",parent,x,y);
	return;
end
-- Sort Buttons for Bars Mode--
function barF2_SortButtons_Bars()
	local bcount =0
	local bSPACING;
	if (barF2.GLOBAL.Shift == true) or (barF2["layout" ..barF2.GLOBAL.Use].Shift == true) then
		barF2.GLOBAL.Shift = barF2["layout" ..barF2.GLOBAL.Use].Shift;
		return;
	end
	for i=1,10 do
		if (barF2["layout" ..barF2.GLOBAL.Use].Bars[i]["count"]>0) then
			local bR=0
			local bY=1
			local bSc = barF2["layout" ..barF2.GLOBAL.Use].Bars[i].scale
			bSPACING = barF2["layout" ..barF2.GLOBAL.Use].Bars[i].Spacing
			for j=1,barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count do
				bcount = bcount+1
				barF2["layout" ..barF2.GLOBAL.Use].Bttns[bcount].parent=("barF2_Frame_" ..i)
				bR = bR+1
				barF2["layout" ..barF2.GLOBAL.Use].Bttns[bcount].x = bR
				barF2["layout" ..barF2.GLOBAL.Use].Bttns[bcount].y = bY
				if (bR == barF2["layout" ..barF2.GLOBAL.Use].Bars[i].row) then
					bR = 0
					bY = bY +1
				end
			end
		end
	end
	--anything else floats --
	if (bcount ~= 80) then
		for i=bcount+1,80 do
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].parent ="UIParent"
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].x = (i-(math.ceil(i/20)*20-20)) * 40
			barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].y = math.ceil(i/20) * 40
		end
	end
end
--place bars/groups and buttons in correct place 
function barF2_place()
	--Hide Games Action bars and set info to hide --

	for i = 1, 4 do
	    local visible, count, row = GetActionBarSetting(i);
	    visible = false;
	    SetActionBarSetting(i, visible, count, row);
	end
	GCF_Page4_ActionBar_Update();

	ToonName,ToonClass = barF2_Toon();
	local bDom = 0
	local bSPACING;
	for i = 1,10 do
		local frame = getglobal("barF2_Frame_" ..i)
		if (barF2["layout" ..barF2.GLOBAL.Use].Bars[i]["count"]~=0) then
			bSPACING = barF2["layout" ..barF2.GLOBAL.Use].Bars[i].Spacing
			bDom=math.ceil(barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count / barF2["layout" ..barF2.GLOBAL.Use].Bars[i].row) --common denominator
			if (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].row>barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count) then
				frame:SetSize(barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count * (42 + bSPACING) ,bDom * (42 + bSPACING));
			else
				frame:SetSize(barF2["layout" ..barF2.GLOBAL.Use].Bars[i].row * (42 + bSPACING) ,bDom * (42 + bSPACING));
			end
			frame:Show();
			frame:SetAlpha(1);
			frame:ClearAllAnchors();
			if ( barF2["layout" ..barF2.GLOBAL.Use].Bars[i].x < 0 ) and (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].IsPressed == "Always") then
				barF2["layout" ..barF2.GLOBAL.Use].Bars[i].x = 1
			end
			if (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].y<0) and (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].IsPressed == "Always") then
				barF2["layout" ..barF2.GLOBAL.Use].Bars[i].y = 1
			end
			barF2_UI_pos(frame);
			--scale--
		else
			frame:Hide();
		end
		if (frame:IsVisible()) and (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].show == false) then
			frame:Hide();
		end
		if (barF2.GLOBAL.Mode=="Config") and (barF2["layout" ..barF2.GLOBAL.Use].Bars[i]["count"]~=0) and (not frame:IsVisible()) then
			frame:Show();
			frame:SetAlpha(0.5);
		end		
	end
	-- buttons --
	for i=1,80 do
		local bttnSk = barF2_CHAR[ToonName][ToonClass][i].skin
		if (bttnSk == "Main") then
			bttnSk = barF2.GLOBAL.Skin
		end
		local bttn = getglobal("barF2_" ..i);
		bttn:ClearAllAnchors();
		barF2_UI_pos(bttn);
		bttn:SetFrameStrata(barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].strata);
		getglobal("barF2_" ..i .."Name"):SetText(i);
		local texture, name, count, locked, wore, continued = GetActionInfo(i);
		if ( wore ) then
			getglobal("barF2_" ..i .."Border"):SetTexture("Interface\\addons\\barF2\\Graphics\\boring\\Normal2.tga");
		elseif (bttnSk == "boring") then
			getglobal("barF2_"..i .."Border"):SetTexture("Interface\\addons\\barF2\\Graphics\\boring\\Normal.tga");
		elseif (bttnSk ~= "boring") then
			getglobal("barF2_"..i .."Border"):SetTexture("Interface\\addons\\barF2\\Graphics\\" ..bttnSk .."\\Normal.tga")
		end
		if ( texture ) then
			getglobal("barF2_" ..i .."Icon"):Show();
			getglobal("barF2_" ..i .."Icon"):SetTexture(texture);
		elseif (bttnSk == "boring") then
			getglobal("barF2_" ..i .."Icon"):Show();
			getglobal("barF2_" ..i .."Icon"):SetTexture("Interface\\Buttons\\QuickSlot-Normal");
		else
			getglobal("barF2_" ..i .."Icon"):Hide();
		end	
		if ( continued ) then
			getglobal("barF2_" ..i.."Continued"):Show();
		else
			getglobal("barF2_" ..i.."Continued"):Hide();
		end
		barF2_UpdateHotkeys(getglobal("barF2_" ..i));
		if (barF2.GLOBAL.Hot == true) then
			getglobal("barF2_" ..i.."Hotkey"):Show();
		else
			getglobal("barF2_" ..i.."Hotkey"):Hide();
		end
		SetItemButtonCount(bttn, count);
		SetItemButtonLuminance(bttn, count == 0);
		barF2_Button_UpdateCooldown(bttn);
		--show/hide
		local obj = barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].parent
		if obj=="UIParent" then
			if (barF2_CHAR[ToonName][ToonClass][i].show == true) then
				bttn:Show();
				bttn:SetAlpha(1.0);
			elseif (barF2_CHAR[ToonName][ToonClass][i].show == false) and (barF2.GLOBAL.Mode == "Config") then
				bttn:Show();
				bttn:SetAlpha(0.5);
			elseif (barF2_CHAR[ToonName][ToonClass][i].autohide == true) and (barF2.GLOBAL.Mode == "Config") then
				getglobal("barF2_" ..i .."Continued"):Show();		
			else
				bttn:Hide();
			end	
			barF2_Bttn_Scale(i,barF2["layout" ..barF2.GLOBAL.Use].Bttns[i].scale);
		else
			local ind = getglobal(obj):GetID();
			if (barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].show == true) and (barF2_CHAR[ToonName][ToonClass][i].show == true) then
				bttn:Show();
				bttn:SetAlpha(1.0);
			else
				bttn:Hide();
			end
			if (barF2.GLOBAL.Mode=="Config") and (not bttn:IsVisible()) then
				bttn:Show();
				bttn:SetAlpha(0.5);
			end
			if (barF2_CHAR[ToonName][ToonClass][i].autohide == true) and (barF2.GLOBAL.Mode == "Config") then
				bttn:SetAlpha(0.5);
				getglobal("barF2_" ..i .."Continued"):Show();	
			end
			barF2_Bttn_Scale(i,barF2["layout" ..barF2.GLOBAL.Use].Bars[ind].scale);
				
		end
	end
end
---------------
---- Skin -----
---------------
function barF2_SkinDisp()
	-- skin set-up
	for i = 1,80 do
		local bBttnSkin=barF2_CHAR[ToonName][ToonClass][i].skin
		if (bBttnSkin == "Main") then
			bBttnSkin = barF2.GLOBAL.Skin
		end
		local bSkinF = "Interface\\addons\\barF2\\Graphics\\" ..bBttnSkin .."\\"
		if (bBttnSkin == "boring") then
			getglobal("barF2_"..i .."Border")       :SetTexture("Interface\\addons\\barF2\\Graphics\\boring\\Normal.tga");
			getglobal("barF2_" ..i .."Pushed")      :SetTexture("Interface\\Buttons\\QuickSlot-Depress");
			getglobal("barF2_" ..i .."Highlight")   :SetTexture("Interface\\Buttons\\QuickSlot-Highlight");
			getglobal("barF2_" ..i .."Active")      :SetTexture("Interface\\addons\\barF2\\Graphics\\Active.tga");
			getglobal("barF2_" ..i .."Invalid")     :SetTexture("Interface\\Buttons\\QuickSlot-Red");
			getglobal("barF2_" ..i .."OverLay")     :Hide();
		else
			getglobal("barF2_" ..i .."Border")      :SetTexture(bSkinF .."Normal.tga");
			getglobal("barF2_" ..i .."Pushed")      :SetTexture(bSkinF .."Pushed.tga");
			getglobal("barF2_" ..i .."Highlight")   :SetTexture(bSkinF .."Highlight.tga");
			getglobal("barF2_" ..i .."Active")      :SetTexture(bSkinF .."Active.tga");
			getglobal("barF2_" ..i .."Invalid")     :SetTexture(bSkinF .."Invalid.tga");
			if (barF2.GLOBAL.Glossy == true) and (barF2_CHAR[ToonName][ToonClass][i].skin == "Main") then
				getglobal("barF2_" ..i .."OverLay") :SetTexture(bSkinF .."Overlay.tga");
				getglobal("barF2_" ..i .."OverLay") :Show();
			elseif (barF2_CHAR[ToonName][ToonClass][i].skin ~= "Main") and (barF2_CHAR[ToonName][ToonClass][i].gloss == true) then
				getglobal("barF2_" ..i .."OverLay") :SetTexture(bSkinF .."Overlay.tga");
				getglobal("barF2_" ..i .."OverLay") :Show();
			else
				getglobal("barF2_" ..i .."OverLay") :Hide();
			end
		end
		
	end
end
--scale--
function barF2_Bttn_Scale(ind,bSc)
	ToonName,ToonClass                                = barF2_Toon();
	local Bttn                                         = getglobal("barF2_"..ind)
	local bBSk=barF2_CHAR[ToonName][ToonClass][ind].skin
	if (bBSk == "Main") then
		bBSk                                           = barF2.GLOBAL.Skin
	end
	Bttn                                                                             :SetSize(36 * bSc,36 * bSc)
	if (bBSk == "boring") then
		getglobal("barF2_" ..ind .."Border")                                         :SetSize(64*bSc,64*bSc);
		getglobal("barF2_" ..ind .."Pushed")                                         :SetSize(64*bSc,64*bSc);
		getglobal("barF2_" ..ind .."Icon")                                           :SetSize(32*bSc,32*bSc);
		getglobal("barF2_" ..ind .."Active")                                         :SetSize(64*bSc,64*bSc);
		getglobal("barF2_" ..ind .."Cooldown")                                       :SetSize(32*bSc,32*bSc);
		getglobal("barF2_" ..ind .."Invalid")                                        :SetSize(32*bSc,32*bSc);
	else
		getglobal("barF2_" ..ind .."Border")                                         :SetSize(50*bSc,50*bSc);
		getglobal("barF2_" ..ind .."Pushed")                                         :SetSize(50*bSc,50*bSc);
		getglobal("barF2_" ..ind .."Icon")                                           :SetSize(32*bSc,32*bSc);
		getglobal("barF2_" ..ind .."Active")                                         :SetSize(50*bSc,50*bSc);
		getglobal("barF2_" ..ind .."Cooldown")                                       :SetSize(32*bSc,32*bSc);
		getglobal("barF2_" ..ind .."Invalid")                                        :SetSize(32*bSc,32*bSc);
		getglobal("barF2_" ..ind .."OverLay")                                        :SetSize(50*bSc,50*bSc);
	end
	
end
---CoolDowns --
function barF2_Button_UpdateCooldown(this)
	local duration, remaining = GetActionCooldown(barF2_GetButtonID(this));
	--if not (getglobal(this:GetName() .."Cooldown"):IsVisible()) then
		CooldownFrame_SetTime(getglobal(this:GetName().."Cooldown"), duration, remaining);
	--end
end

--Update Hotkeys --
function barF2_UpdateHotkeys(this)
	
end
--when first starting or on layout change on mass change --
function barF2_Hotkeys_Layout()
	for i=1,80 do
		local keyname = "ACTIONBAR"..math.ceil(i/20) .."BUTTON"..(i-(math.ceil(i/20)*20-20));
		if barF2["layout"..barF2.GLOBAL.Use].Bttns[i].Hotkey == nil then
			local keyd = GetBindingKey(keyname);
			if (keyd) then
				barF2["layout"..barF2.GLOBAL.Use].Bttns[i]["Hotkey"] = keyd
			else
				barF2["layout"..barF2.GLOBAL.Use].Bttns[i]["Hotkey"] = "undefined"
			end
		end
		local hotkey = getglobal("barF2_"..i.."Hotkey");
		local key = barF2["layout"..barF2.GLOBAL.Use].Bttns[i].Hotkey
		if  (key == "undefined") then
			SetBindingKey(keyname,KDF_UNDEFINE);
			SaveBindingKey();
			hotkey:SetText("");
		else
			SetBindingKey(keyname,key);
			SaveBindingKey();
			if string.find( key, "+") then
				local fkey_start,fkey_end = string.find( key, "+")
				key = string.sub(key,1,1) ..string.sub(key,fkey_end)
			end
			hotkey:SetText(key);
		end
	end
	barF2_place();
end
-- Show/Hide Numbers on buttons and bar/groups--
function barF2_ShowNumbers()
	for i =1,80 do
		if (barF2.GLOBAL.Mode == "Config") then
			getglobal("barF2_" ..i .."Name"):Show();
		else
			getglobal("barF2_" ..i .."Name"):Hide();
		end
	end
	for i = 1,10 do
		if (barF2.GLOBAL.Mode == "Config") and (barF2["layout" ..barF2.GLOBAL.Use].Bars[i].count>1) then
			local tab_frame=getglobal("barF2_Tab_" ..i)
			tab_frame:ClearAllAnchors();
			tab_frame:SetAnchor("TOPLEFT","TOPLEFT",getglobal("barF2_Frame_"..i),-10,-30);
			tab_frame:Show();
			getglobal("barF2_Tab_" ..i .."_Text"):SetText("#" ..i);
			getglobal("barF2_Tab_" ..i .."_Text"):SetColor(1,0,1);
		else
			getglobal("barF2_Tab_" ..i):Hide();
		end
	end
end
-- minimap button tooltip--
function barF2_MiniTool(this)
	GameTooltip:SetOwner(this, "ANCHOR_TOPLEFT", 10, -10);
	GameTooltip:SetText("barF2 "..barF2.GLOBAL.Version, 1, 1, 0);
	GameTooltip:AddLine("Click to Configure", 1, 1, 0);
	GameTooltip:AddLine("Use Mouse Wheel to ",1,0.5,0)
	GameTooltip:AddLine("change Current Layout :"..barF2.GLOBAL.Use, 1, 0.5, 0);
	GameTooltip:AddLine(UI_MINIMAPBUTTON_MOVE, 0, 0.75, 0.95);
	GameTooltip:Show();
end