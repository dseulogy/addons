local UAWSActionbarNames = {"MainActionBarFrame", "BottomActionBarFrame", "RightActionBarFrame", "LeftActionBarFrame"};

function UAWSOnDragBegin(this)
	if ( IsShiftKeyDown() ) then
		PickupAction(ActionButton_GetButtonID(this));
	end
end
function UAWSOnReceiveDrag(this)
	if ( CursorHasItem() ) then
		PickupAction(ActionButton_GetButtonID(this));
	end
end

for i = 1, 4 do
	for j = 1, ACTIONBAR_NUM_BUTTONS do
		getglobal(UAWSActionbarNames[i] .. "Button" .. j)["__uiLuaOnDragBegin__"] = UAWSOnDragBegin;
		getglobal(UAWSActionbarNames[i] .. "Button" .. j)["__uiLuaOnReceiveDrag__"] = UAWSOnReceiveDrag;
	end
end